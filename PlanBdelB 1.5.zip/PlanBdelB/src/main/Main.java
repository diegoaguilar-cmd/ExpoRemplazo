
package main;

import javax.swing.SwingUtilities;

public class Main {

    public static void main(String[] args) {
        // Esto le dice a Java que abra tu ventana de forma segura
        SwingUtilities.invokeLater(() -> {
            Menu miMenu = new Menu();
            miMenu.setVisible(true); // Hace que la ventana sea visible
        });
    }
    
}

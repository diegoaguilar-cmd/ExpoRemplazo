package main;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.io.File;

public class Login extends JFrame {
    private JFrame menuPrincipal; // 🌟 Guardará la referencia al menú original
    private boolean contraseñaVisible = false;

    // 🌟 CONSTRUCTOR AUXILIAR: Permite ejecutar el Login directamente desde su main sin errores
    public Login() {
        this(null);
    }

    // Constructor principal que recibe el menú
    public Login(JFrame menuPrincipal) {
        this.menuPrincipal = menuPrincipal;
        setTitle("Rema - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // 1. Quitamos los bordes de la ventana
        setUndecorated(true);

        // 2. Obtenemos el tamaño exacto de toda la pantalla (incluyendo barra de tareas)
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setSize(screenSize);

        // 3. La posicionamos en la esquina superior izquierda
        setLocation(0, 0);

        // Panel principal con fondo degradado azul oscuro
        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                GradientPaint gp = new GradientPaint(
                        0, 0, Color.decode("#071224"),
                        getWidth(), getHeight(), Color.decode("#0c1b3a")
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setLayout(new GridBagLayout());
        setContentPane(mainPanel);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1.0;

        // --- SECCIÓN IZQUIERDA: Información y Bienvenida ---
        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setOpaque(false);
        leftPanel.setBorder(BorderFactory.createEmptyBorder(40, 60, 40, 40));

        JPanel topContainer = new JPanel();
        topContainer.setLayout(new BoxLayout(topContainer, BoxLayout.Y_AXIS));
        topContainer.setOpaque(false);

        JLabel lblVolver = new JLabel("← Volver al Menú");
        lblVolver.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblVolver.setForeground(Color.decode("#8fa0bc"));
        lblVolver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        lblVolver.setAlignmentX(Component.LEFT_ALIGNMENT);

        lblVolver.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // 1. Detectamos automáticamente la ventana actual (tu Login)
                JFrame ventanaActual = (JFrame) SwingUtilities.getWindowAncestor(lblVolver);
                
                // 2. Si menuPrincipal es null (caso de testeo), creamos uno nuevo para que no rompa 🌟
                JFrame destino = (menuPrincipal != null) ? menuPrincipal : new Menu();
                
                // 3. ¡Ejecutamos la transición sin que jamás vuelva a dar error!
                TransicionElegante.cambiarVentana(ventanaActual, destino);
            }
        });
        
        JLabel brandLogoLabel = new JLabel();
        brandLogoLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        String rutaImagen = "imagenes/E.png";
        File archivoImagen = new File(rutaImagen);
        if (archivoImagen.exists()) {
            ImageIcon iconoOriginal = new ImageIcon(rutaImagen);
            Image imagenEscalada = iconoOriginal.getImage().getScaledInstance(110, 50, Image.SCALE_SMOOTH);
            brandLogoLabel.setIcon(new ImageIcon(imagenEscalada));
        } else {
            brandLogoLabel.setText("REMA");
            brandLogoLabel.setFont(new Font("SansSerif", Font.BOLD, 22));
            brandLogoLabel.setForeground(Color.WHITE);
        }

        topContainer.add(lblVolver);
        topContainer.add(Box.createRigidArea(new Dimension(0, 25)));
        topContainer.add(brandLogoLabel);
        leftPanel.add(topContainer, BorderLayout.NORTH);

        JPanel centerTextPanel = new JPanel(new GridBagLayout());
        centerTextPanel.setOpaque(false);
        GridBagConstraints gbcText = new GridBagConstraints();
        gbcText.gridx = 0;
        gbcText.weightx = 1.0;
        gbcText.anchor = GridBagConstraints.WEST;
        gbcText.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("<html>BIENVENIDOS<br>DE VUELTA</html>");
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 46));
        titleLabel.setForeground(Color.WHITE);

        JLabel subtitleLabel = new JLabel("<html>Accede al sistema de gestión de préstamos de<br>herramientas del Instituto Técnico.</html>");
        subtitleLabel.setFont(new Font("SansSerif", Font.PLAIN, 15));
        subtitleLabel.setForeground(Color.decode("#8fa0bc"));

        gbcText.gridy = 0;
        centerTextPanel.add(titleLabel, gbcText);
        gbcText.gridy = 1;
        gbcText.insets = new Insets(20, 0, 0, 0);
        centerTextPanel.add(subtitleLabel, gbcText);

        leftPanel.add(centerTextPanel, BorderLayout.CENTER);

        JLabel footerLabel = new JLabel("MANTENIENDO A FLOTE EL ORDEN - 2026");
        footerLabel.setFont(new Font("SansSerif", Font.PLAIN, 11));
        footerLabel.setForeground(Color.decode("#4c5e7b"));
        leftPanel.add(footerLabel, BorderLayout.SOUTH);

        gbc.gridx = 0;
        gbc.weightx = 0.55;
        mainPanel.add(leftPanel, gbc);

        // --- SECCIÓN DERECHA: Tarjeta de Login con Aura Azul Suave ---
        JPanel rightPanel = new JPanel(new GridBagLayout());
        rightPanel.setOpaque(false);
        rightPanel.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 60));

        JPanel cardPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int auraSize = 22; // Radio del brillo
                int cardWidth = getWidth() - (auraSize * 2);
                int cardHeight = getHeight() - (auraSize * 2);
                int arc = 35;

                // 🌟 Aura azul pero con opacidad inicial sumamente baja (4 en canal alfa)
                Color auraColor = new Color(59, 130, 246, 4);

                // Pintamos las capas decrecientes para lograr un difuminado sutil
                for (int i = auraSize; i > 0; i--) {
                    // La opacidad va subiendo muy lentamente a medida que se acerca al borde blanco
                    int alpha = (int) Math.min(25, (auraSize - i) * 1.2);
                    g2d.setColor(new Color(auraColor.getRed(), auraColor.getGreen(), auraColor.getBlue(), alpha));
                    g2d.fill(new RoundRectangle2D.Double(
                            auraSize - i,
                            auraSize - i,
                            cardWidth + (i * 2),
                            cardHeight + (i * 2),
                            arc + i,
                            arc + i
                    ));
                }

                // Tarjeta blanca sólida
                g2d.setColor(Color.WHITE);
                g2d.fill(new RoundRectangle2D.Double(auraSize, auraSize, cardWidth, cardHeight, arc, arc));
            }
        };
        cardPanel.setOpaque(false);
        cardPanel.setPreferredSize(new Dimension(430, 580));
        cardPanel.setLayout(new BoxLayout(cardPanel, BoxLayout.Y_AXIS));
        cardPanel.setBorder(BorderFactory.createEmptyBorder(60, 55, 60, 55));

        JLabel loginHeader = new JLabel("Login");
        loginHeader.setFont(new Font("SansSerif", Font.BOLD, 28));
        loginHeader.setForeground(Color.decode("#111827"));
        loginHeader.setAlignmentX(Component.CENTER_ALIGNMENT);

        Dimension fieldSize = new Dimension(320, 42);

        // --- Campo: Correo ---
        JLabel emailLabel = new JLabel("Correo electrónico");
        emailLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
        emailLabel.setForeground(Color.decode("#4b5563"));
        emailLabel.setMaximumSize(new Dimension(320, 16));
        emailLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JTextField emailField = new JTextField("tu@correo.com");
        emailField.setFont(new Font("SansSerif", Font.PLAIN, 13));
        emailField.setForeground(Color.GRAY);
        emailField.setBackground(Color.decode("#f9fafb"));
        emailField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.decode("#e5e7eb"), 1, true),
                new EmptyBorder(10, 15, 10, 15)
        ));
        emailField.setMaximumSize(fieldSize);
        emailField.setAlignmentX(Component.CENTER_ALIGNMENT);

        emailField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (emailField.getText().trim().equals("tu@correo.com")) {
                    emailField.setText("");
                    emailField.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (emailField.getText().trim().isEmpty()) {
                    emailField.setText("tu@correo.com");
                    emailField.setForeground(Color.GRAY);
                }
            }
        });

        // --- Campo: Contraseña ---
        JLabel passLabel = new JLabel("Contraseña");
        passLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
        passLabel.setForeground(Color.decode("#4b5563"));
        passLabel.setMaximumSize(new Dimension(320, 16));
        passLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel wrapperPassword = new JPanel(new BorderLayout());
        wrapperPassword.setBackground(Color.decode("#f9fafb"));
        wrapperPassword.setMaximumSize(fieldSize);
        wrapperPassword.setBorder(BorderFactory.createLineBorder(Color.decode("#e5e7eb"), 1, true));
        wrapperPassword.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPasswordField passField = new JPasswordField("Tu contraseña");
        passField.setEchoChar((char) 0);
        passField.setFont(new Font("SansSerif", Font.PLAIN, 13));
        passField.setForeground(Color.GRAY);
        passField.setBackground(Color.decode("#f9fafb"));
        passField.setBorder(new EmptyBorder(10, 15, 10, 5));

        passField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                String contraString = String.valueOf(passField.getPassword());
                if (contraString.equals("Tu contraseña")) {
                    passField.setText("");
                    passField.setForeground(Color.BLACK);
                    // Oculta con puntitos si el botón del ojo no está activado
                    if (!contraseñaVisible) {
                        passField.setEchoChar('•');
                    }
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                String contraString = String.valueOf(passField.getPassword());
                if (contraString.isEmpty()) {
                    passField.setText("Tu contraseña");
                    passField.setForeground(Color.GRAY);
                    passField.setEchoChar((char) 0);
                }
            }
        });

        JLabel lblOjo = new JLabel();
        lblOjo.setCursor(new Cursor(Cursor.HAND_CURSOR));
        lblOjo.setBorder(new EmptyBorder(0, 0, 0, 12));

        ImageIcon iconVer = null;
        ImageIcon iconOcultar = null;

        if (new File("imagenes/view.png").exists() && new File("imagenes/close-eye.png").exists()) {
            iconVer = new ImageIcon(new ImageIcon("imagenes/view.png").getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH));
            iconOcultar = new ImageIcon(new ImageIcon("imagenes/close-eye.png").getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH));
            lblOjo.setIcon(iconOcultar);
        } else {
            lblOjo.setText("👁");
            lblOjo.setFont(new Font("SansSerif", Font.PLAIN, 16));
        }

        ImageIcon finalIconVer = iconVer;
        ImageIcon finalIconOcultar = iconOcultar;
        lblOjo.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                contraseñaVisible = !contraseñaVisible;
                String contraString = String.valueOf(passField.getPassword());

                if (contraseñaVisible) {
                    if (finalIconVer != null) {
                        lblOjo.setIcon(finalIconVer);
                    } else {
                        lblOjo.setText("🔒");
                    }
                } else {
                    if (finalIconOcultar != null) {
                        lblOjo.setIcon(finalIconOcultar);
                    } else {
                        lblOjo.setText("👁");
                    }
                }

                // Modifica el estado del enmascarado respetando que no sea el placeholder
                if (!contraString.equals("Tu contraseña")) {
                    if (contraseñaVisible) {
                        passField.setEchoChar((char) 0);
                    } else {
                        passField.setEchoChar('•');
                    }
                }
            }
        });

        wrapperPassword.add(passField, BorderLayout.CENTER);
        wrapperPassword.add(lblOjo, BorderLayout.EAST);

        // Olvidé mi contraseña
        JLabel forgotLabel = new JLabel("Olvidé mi contraseña");
        forgotLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
        forgotLabel.setForeground(Color.decode("#2563eb"));
        forgotLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JPanel forgotWrapper = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        forgotWrapper.setOpaque(false);
        forgotWrapper.setMaximumSize(new Dimension(320, 22));
        forgotWrapper.setAlignmentX(Component.CENTER_ALIGNMENT);
        forgotWrapper.add(forgotLabel);

        // Botón "Vamos →"
        JButton btnVamos = new JButton("Vamos →") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isRollover()) {
                    g2d.setColor(Color.decode("#1d4ed8"));
                } else {
                    g2d.setColor(Color.decode("#2563eb"));
                }
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 16, 16);
                g2d.dispose();
                super.paintComponent(g); 
            }
        };
        btnVamos.setFont(new Font("SansSerif", Font.BOLD, 14));
        btnVamos.setForeground(Color.WHITE);
        btnVamos.setContentAreaFilled(false);
        btnVamos.setBorderPainted(false);
        btnVamos.setFocusPainted(false);
        btnVamos.setMaximumSize(new Dimension(320, 46));
        btnVamos.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnVamos.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        // Acción de iniciar sesión al dar clic:
        btnVamos.addActionListener(e -> {
            // Lógica para validar el correo y contraseña...
            System.out.println("Intentando iniciar sesión...");
        });

        JLabel registerLabel = new JLabel("<html><font color='#4b5563'>No tienes una cuenta? </font><b><font color='#2563eb'>Regístrate</font></b></html>");
        registerLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        registerLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        registerLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        // Ensamblar la tarjeta
        cardPanel.add(loginHeader);
        cardPanel.add(Box.createRigidArea(new Dimension(0, 30)));

        cardPanel.add(emailLabel);
        cardPanel.add(Box.createRigidArea(new Dimension(0, 6)));
        cardPanel.add(emailField);
        cardPanel.add(Box.createRigidArea(new Dimension(0, 18)));

        cardPanel.add(passLabel);
        cardPanel.add(Box.createRigidArea(new Dimension(0, 6)));
        cardPanel.add(wrapperPassword);
        cardPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        cardPanel.add(forgotWrapper);
        cardPanel.add(Box.createRigidArea(new Dimension(0, 30)));

        cardPanel.add(btnVamos);
        cardPanel.add(Box.createRigidArea(new Dimension(0, 25)));
        cardPanel.add(registerLabel);

        GridBagConstraints gbcCard = new GridBagConstraints();
        gbcCard.gridx = 0;
        gbcCard.gridy = 0;
        rightPanel.add(cardPanel, gbcCard);

        gbc.gridx = 1;
        gbc.weightx = 0.45;
        mainPanel.add(rightPanel, gbc);
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
        }
        SwingUtilities.invokeLater(() -> {
            // 🌟 Ahora arranca perfectamente llamando al constructor auxiliar sin parámetros
            new Login().setVisible(true);
        });
    }
}
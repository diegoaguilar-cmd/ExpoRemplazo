package Principal;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TransicionElegante {

    public static void cambiarVentana(JFrame ventanaActual, JFrame ventanaDestino) {
        // Aseguramos que la ventana de destino empiece totalmente invisible pero activa
        ventanaDestino.setOpacity(0f);
        ventanaDestino.setVisible(true);

        // --- FASE 1: Fade Out (Desvanecer ventana actual) ---
        Timer timerFadeOut = new Timer(10, null);
        timerFadeOut.addActionListener(new ActionListener() {
            private float opacidad = 1.0f;

            @Override
            public void actionPerformed(ActionEvent e) {
                opacidad -= 0.05f;
                if (opacidad <= 0.0f) {
                    ventanaActual.setOpacity(0.0f);
                    timerFadeOut.stop();
                    
                    // 🌟 LA CLAVE: Solo la ocultamos, no la destruimos
                    ventanaActual.setVisible(false); 
                    
                    // --- FASE 2: Fade In (Aparecer ventana destino) ---
                    iniciarFadeIn(ventanaDestino);
                } else {
                    ventanaActual.setOpacity(opacidad);
                }
            }
        });
        timerFadeOut.start();
    }

    private static void iniciarFadeIn(JFrame ventana) {
        Timer timerFadeIn = new Timer(10, null);
        timerFadeIn.addActionListener(new ActionListener() {
            private float opacidad = 0.0f;

            @Override
            public void actionPerformed(ActionEvent e) {
                opacidad += 0.05f;
                if (opacidad >= 1.0f) {
                    ventana.setOpacity(1.0f);
                    timerFadeIn.stop();
                } else {
                    ventana.setOpacity(opacidad);
                }
            }
        });
        timerFadeIn.start();
    }
}
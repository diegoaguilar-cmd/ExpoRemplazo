
package Principal;

import javax.swing.SwingUtilities;

public class ApartadoPrincipal {

    public static void main(String[] args) {
        // Esto le dice a Java que abra tu ventana de forma segura
        SwingUtilities.invokeLater(() -> {
            MenuPrincipal miMenu = new MenuPrincipal();
            miMenu.setVisible(true); // Hace que la ventana sea visible
        });
    }
    
}

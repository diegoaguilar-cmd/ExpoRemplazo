package Principal.Usuario;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.text.JTextComponent;

public class VistaIncidencias extends JPanel {

    // Paleta de colores idéntica al diseño
    private static final Color COLOR_BG = new Color(11, 13, 23);         
    private static final Color COLOR_CARD_BG = new Color(20, 26, 47);    
    private static final Color COLOR_INPUT_BG = new Color(30, 37, 58);   
    private static final Color COLOR_TEXT_MUTED = new Color(110, 118, 142); 
    private static final Color COLOR_TEXT_LIGHT = new Color(240, 242, 245); 
    
    // Colores de acento
    private static final Color COLOR_BLUE_BTN = new Color(0, 119, 255);
    private static final Color COLOR_GREEN_CHECK = new Color(46, 204, 113);

    // Componentes interactivos
    private final RoundedPanel btnAccionSuperior;
    private final JLabel lblTextoBotonSuperior;
    private final RoundedPanel panelFormulario;
    private boolean formularioVisible = false;

    public VistaIncidencias() {
        setBackground(COLOR_BG);
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        // ==========================================
        // 1. ENCABEZADO (Título e Icono + Botón de Acción)
        // ==========================================
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        // Título con el icono de advertencia
        JLabel lblTitulo = new JLabel("⚠️  Incidencias Reportadas");
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 24));
        lblTitulo.setForeground(COLOR_TEXT_LIGHT);
        headerPanel.add(lblTitulo, BorderLayout.WEST);

        // Botón de la esquina superior derecha (+ Nueva Incidencia / ✕ Cerrar)
        btnAccionSuperior = new RoundedPanel(15, COLOR_BLUE_BTN);
        btnAccionSuperior.setLayout(new GridBagLayout());
        btnAccionSuperior.setPreferredSize(new Dimension(160, 38));
        btnAccionSuperior.setCursor(new Cursor(Cursor.HAND_CURSOR));

        lblTextoBotonSuperior = new JLabel("+ Nueva Incidencia");
        lblTextoBotonSuperior.setFont(new Font("SansSerif", Font.BOLD, 12));
        lblTextoBotonSuperior.setForeground(COLOR_TEXT_LIGHT);
        btnAccionSuperior.add(lblTextoBotonSuperior);
        
        headerPanel.add(btnAccionSuperior, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);

        // ==========================================
        // 2. CONTENIDO CENTRAL (Formulario + Mensaje de Estado Vacío)
        // ==========================================
        JPanel contentCenter = new JPanel(new GridBagLayout());
        contentCenter.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        // --- SUBPANEL A: Formulario de Incidencia (Oculto por defecto) ---
        panelFormulario = crearFormulario();
        panelFormulario.setVisible(false); // Oculto al inicio
        gbc.gridy = 0;
        gbc.insets = new Insets(15, 0, 25, 0);
        contentCenter.add(panelFormulario, gbc);

        // --- SUBPANEL B: Mensaje de Estado Vacío (Siempre visible) ---
        JPanel emptyStatePanel = crearMensajeVacio();
        gbc.gridy = 1;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(20, 0, 0, 0);
        contentCenter.add(emptyStatePanel, gbc);

        add(contentCenter, BorderLayout.CENTER);

        // ==========================================
        // 3. LÓGICA DE INTERACCIÓN (Alternar Formulario)
        // ==========================================
        btnAccionSuperior.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                toggleFormulario();
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                btnAccionSuperior.setBackgroundColor(COLOR_BLUE_BTN.brighter());
                btnAccionSuperior.repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btnAccionSuperior.setBackgroundColor(COLOR_BLUE_BTN);
                btnAccionSuperior.repaint();
            }
        });
    }

    // Alternar visibilidad del formulario con su respectivo cambio de diseño de botón
    private void toggleFormulario() {
        formularioVisible = !formularioVisible;
        panelFormulario.setVisible(formularioVisible);
        
        if (formularioVisible) {
            lblTextoBotonSuperior.setText("✕ Cerrar");
        } else {
            lblTextoBotonSuperior.setText("+ Nueva Incidencia");
        }
        
        // Refrescar y reordenar visualmente el panel
        revalidate();
        repaint();
    }

    // Método que dibuja la caja del formulario (Idéntico a la Imagen 2)
    private RoundedPanel crearFormulario() {
        RoundedPanel form = new RoundedPanel(18, COLOR_CARD_BG);
        form.setLayout(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        gbc.insets = new Insets(0, 0, 15, 0);

        // 1. Campo TÍTULO
        JLabel lblTitulo = new JLabel("TÍTULO");
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 10));
        lblTitulo.setForeground(COLOR_TEXT_MUTED);
        gbc.gridy = 0;
        form.add(lblTitulo, gbc);

        JTextField txtTitulo = new JTextField();
        txtTitulo.setBackground(COLOR_INPUT_BG);
        txtTitulo.setFont(new Font("SansSerif", Font.PLAIN, 12));
        txtTitulo.setCaretColor(COLOR_TEXT_LIGHT);
        txtTitulo.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_INPUT_BG, 1),
                BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));
        // Configuración formal del comportamiento placeholder
        configurarPlaceholder(txtTitulo, "Ej. Equipo dañado");
        
        gbc.gridy = 1;
        form.add(txtTitulo, gbc);

        // 2. Campo DESCRIPCIÓN
        JLabel lblDesc = new JLabel("DESCRIPCIÓN");
        lblDesc.setFont(new Font("SansSerif", Font.BOLD, 10));
        lblDesc.setForeground(COLOR_TEXT_MUTED);
        gbc.gridy = 2;
        form.add(lblDesc, gbc);

        JTextArea txtDesc = new JTextArea();
        txtDesc.setBackground(COLOR_INPUT_BG);
        txtDesc.setFont(new Font("SansSerif", Font.PLAIN, 12));
        txtDesc.setLineWrap(true);
        txtDesc.setWrapStyleWord(true);
        txtDesc.setCaretColor(COLOR_TEXT_LIGHT);
        txtDesc.setBorder(BorderFactory.createEmptyBorder(12, 15, 12, 15));
        // Configuración formal del comportamiento placeholder
        configurarPlaceholder(txtDesc, "Describe el problema detalladamente...");
        
        // Envolver área de texto para que tenga esquinas redondeadas visualmente
        JPanel descWrapper = new JPanel(new BorderLayout());
        descWrapper.setOpaque(false);
        descWrapper.setPreferredSize(new Dimension(0, 90));
        descWrapper.add(txtDesc, BorderLayout.CENTER);
        
        gbc.gridy = 3;
        form.add(descWrapper, gbc);
// --- 3. Campo SEVERIDAD (Solución Definitiva y Forzada de Color) ---
        JLabel lblSeveridad = new JLabel("SEVERIDAD");
        lblSeveridad.setFont(new Font("SansSerif", Font.BOLD, 10));
        lblSeveridad.setForeground(COLOR_TEXT_MUTED); // Gris suave para la etiqueta superior
        gbc.gridy = 4;
        form.add(lblSeveridad, gbc);

        String[] severidades = {"Baja", "Media", "Alta", "Crítica"};
        JComboBox<String> cbSeveridad = new JComboBox<>(severidades);
        
        // 1. Configuraciones de base para el JComboBox principal
        cbSeveridad.setFont(new Font("SansSerif", Font.PLAIN, 12));
        cbSeveridad.setBackground(COLOR_INPUT_BG);   // Fondo oscuro
        // cbSeveridad.setForeground(COLOR_TEXT_LIGHT); // Esto Swing a veces lo ignora, por eso la solución de abajo

        /* -----------------------------------------------------------------
         * SOLUCIÓN INTEGRAL PARA FORZAR COLOR DE LETRA (EDITOR Y LISTA)
         * ----------------------------------------------------------------- */
        
        // A. Forzamos el color de la letra en el elemento SELECCIONADO (cuando está cerrado)
        // Convertimos el combo en editable pero personalizamos el editor para que sea oscuro y blanco.
        cbSeveridad.setEditable(true);
        cbSeveridad.setEditor(new javax.swing.plaf.basic.BasicComboBoxEditor() {
            @Override
            protected JTextField createEditorComponent() {
                JTextField editor = super.createEditorComponent();
                editor.setBackground(COLOR_INPUT_BG);   // Fondo oscuro
                editor.setForeground(COLOR_TEXT_LIGHT); // LETRA BLANCA PURO (FORZADO)
                editor.setCaretColor(COLOR_TEXT_LIGHT); // Cursor blanco si se edita
                editor.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 0)); // Ajuste de padding interno
                editor.setEditable(false); // Evitamos que el usuario escriba, simulando un combo normal
                return editor;
            }
        });

        // B. Forzamos el color de la letra en la LISTA DESPLEGABLE (Renderizador)
        // (Esto es lo mismo de antes, necesario para cuando abres el combo)
        cbSeveridad.setRenderer(new javax.swing.DefaultListCellRenderer() {
            @Override
            public java.awt.Component getListCellRendererComponent(
                    javax.swing.JList<?> list, Object value, int index, 
                    boolean isSelected, boolean cellHasFocus) {
                
                // Obtenemos el componente base (un JLabel)
                java.awt.Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                
                // Forzamos que sea opaco
                if (c instanceof javax.swing.JLabel) {
                    ((javax.swing.JLabel) c).setOpaque(true);
                }

                // Definimos los colores MANUALE E INAPELABLES
                if (isSelected) {
                    // Estado Seleccionado (Hover): Fondo Azul, Texto Blanco
                    c.setBackground(COLOR_BLUE_BTN);
                    c.setForeground(COLOR_TEXT_LIGHT); // Texto blanco
                } else {
                    // Estado Normal en la lista: Fondo Oscuro, Texto Blanco
                    c.setBackground(COLOR_INPUT_BG);
                    c.setForeground(COLOR_TEXT_LIGHT); // Texto blanco
                }

                return c;
            }
        });
        
        // Forzamos opacidad y borde general
        cbSeveridad.setOpaque(true);
        cbSeveridad.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        /* ----------------------------------------------------------------- */

        gbc.gridy = 5;
        form.add(cbSeveridad, gbc);
        
        // 4. Botón Reportar Incidencia
        RoundedPanel btnReportar = new RoundedPanel(12, COLOR_BLUE_BTN);
        btnReportar.setLayout(new GridBagLayout());
        btnReportar.setPreferredSize(new Dimension(160, 38));
        btnReportar.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JLabel lblReportar = new JLabel("Reportar Incidencia");
        lblReportar.setFont(new Font("SansSerif", Font.BOLD, 12));
        lblReportar.setForeground(COLOR_TEXT_LIGHT);
        btnReportar.add(lblReportar);

        // Agregamos interactividad básica al botón interno del formulario
        btnReportar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Aquí puedes agregar la acción para guardar la incidencia en tu lógica interna
                toggleFormulario(); // Cierra el formulario tras reportar
            }
            @Override
            public void mouseEntered(MouseEvent e) {
                btnReportar.setBackgroundColor(COLOR_BLUE_BTN.brighter());
                btnReportar.repaint();
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btnReportar.setBackgroundColor(COLOR_BLUE_BTN);
                btnReportar.repaint();
            }
        });

        // Contenedor alineado a la izquierda para el botón
        JPanel btnWrapper = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        btnWrapper.setOpaque(false);
        btnWrapper.add(btnReportar);

        gbc.gridy = 6;
        gbc.insets = new Insets(10, 0, 0, 0);
        form.add(btnWrapper, gbc);

        return form;
    }

    // Método que dibuja la caja de "Sin incidencias" (Idéntico a la Imagen 1)
    private JPanel crearMensajeVacio() {
        JPanel emptyPanel = new JPanel(new GridBagLayout());
        emptyPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.CENTER;

        // Icono check verde redondeado
        RoundedPanel pnlCheck = new RoundedPanel(12, COLOR_GREEN_CHECK);
        pnlCheck.setPreferredSize(new Dimension(42, 42));
        pnlCheck.setLayout(new GridBagLayout());
        JLabel lblCheck = new JLabel("✓");
        lblCheck.setFont(new Font("SansSerif", Font.BOLD, 22));
        lblCheck.setForeground(COLOR_TEXT_LIGHT);
        pnlCheck.add(lblCheck);

        gbc.gridy = 0;
        gbc.insets = new Insets(0, 0, 15, 0);
        emptyPanel.add(pnlCheck, gbc);

        // Título del estado vacío
        JLabel lblEmptyTitle = new JLabel("Sin incidencias reportadas");
        lblEmptyTitle.setFont(new Font("SansSerif", Font.BOLD, 15));
        lblEmptyTitle.setForeground(COLOR_TEXT_LIGHT);
        gbc.gridy = 1;
        gbc.insets = new Insets(0, 0, 6, 0);
        emptyPanel.add(lblEmptyTitle, gbc);

        // Subtexto descriptivo
        JLabel lblEmptySub = new JLabel("No has reportado ninguna incidencia todavía.");
        lblEmptySub.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblEmptySub.setForeground(COLOR_TEXT_MUTED);
        gbc.gridy = 2;
        gbc.insets = new Insets(0, 0, 0, 0);
        emptyPanel.add(lblEmptySub, gbc);

        return emptyPanel;
    }

    /**
     * Aplica la lógica formal para el manejo del texto instructivo (placeholder).
     * El texto se oculta automáticamente al ganar el foco y se restaura si el usuario no ingresa datos.
     *
     * @param componente       El JTextComponent (JTextField o JTextArea) a configurar.
     * @param textoPlaceholder El mensaje predeterminado a mostrar.
     */
    private void configurarPlaceholder(final JTextComponent componente, final String textoPlaceholder) {
        componente.setText(textoPlaceholder);
        componente.setForeground(COLOR_TEXT_MUTED);

        componente.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (componente.getText().equals(textoPlaceholder)) {
                    componente.setText("");
                    componente.setForeground(COLOR_TEXT_LIGHT);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (componente.getText().trim().isEmpty()) {
                    componente.setText(textoPlaceholder);
                    componente.setForeground(COLOR_TEXT_MUTED);
                }
            }
        });
    }

    // Clase interna para paneles con esquinas redondeadas
    static class RoundedPanel extends JPanel {
        private final int cornerRadius;
        private Color backgroundColor;

        public RoundedPanel(int radius, Color bgColor) {
            this.cornerRadius = radius;
            this.backgroundColor = bgColor;
            setOpaque(false); 
        }

        public void setBackgroundColor(Color color) {
            this.backgroundColor = color;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D graphics = (Graphics2D) g;
            graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            graphics.setColor(backgroundColor);
            graphics.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), cornerRadius, cornerRadius));
        }
    }
}
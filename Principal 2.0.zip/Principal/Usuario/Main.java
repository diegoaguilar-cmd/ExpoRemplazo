
package Principal.Usuario;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
public class Main {
   
    public static void main(String[] args) {
            // Ejecutamos la interfaz en el hilo de despacho de eventos de Swing (hilo seguro para interfaces gráficas)
        SwingUtilities.invokeLater(() -> {
            try {
                // Aplicamos el diseño visual del sistema operativo actual (Windows, Mac, Linux)
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            
            // Creamos la instancia del Dashboard y la hacemos visible
            Dashboard miDashboard = new Dashboard();
            miDashboard.setVisible(true);
        });
    }
            
    }
    


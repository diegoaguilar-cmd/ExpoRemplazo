package Principal.Usuario;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class VistaPrestamos extends JPanel {

    // Paleta de colores idéntica al Dashboard
    private static final Color COLOR_BG = new Color(11, 13, 23);         
    private static final Color COLOR_CARD_BG = new Color(20, 26, 47);    
    private static final Color COLOR_TEXT_MUTED = new Color(110, 118, 142); 
    private static final Color COLOR_TEXT_LIGHT = new Color(240, 242, 245); 

    public VistaPrestamos() {
        // Configuramos el panel principal
        setBackground(COLOR_BG);
        setLayout(new GridBagLayout());
        setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        // 1. Título de la Sección
        JLabel lblTitulo = new JLabel("Mis Préstamos");
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 24));
        lblTitulo.setForeground(COLOR_TEXT_LIGHT);
        gbc.gridy = 0;
        gbc.insets = new Insets(0, 0, 20, 0);
        add(lblTitulo, gbc);

        // 2. Contenedor Principal (Tarjeta redondeada)
        RoundedPanel tableCard = new RoundedPanel(18, COLOR_CARD_BG);
        tableCard.setLayout(new BorderLayout());
        
        // Cabecera de la tabla con línea divisora inferior
        JPanel tableHeader = new JPanel(new GridLayout(1, 5, 10, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(new Color(30, 38, 64)); // Línea divisora sutil
                g.drawLine(0, getHeight() - 1, getWidth(), getHeight() - 1);
            }
        };
        tableHeader.setOpaque(false);
        tableHeader.setPreferredSize(new Dimension(0, 45));
        tableHeader.setBorder(BorderFactory.createEmptyBorder(0, 25, 0, 25));

        // Nombres de las columnas
        String[] columnas = {"EQUIPO", "CÓDIGO", "PRÉSTAMO", "DEVOLUCIÓN", "ESTADO"};
        for (String col : columnas) {
            JLabel lblCol = new JLabel(col);
            lblCol.setFont(new Font("SansSerif", Font.BOLD, 10));
            lblCol.setForeground(COLOR_TEXT_MUTED);
            if (!col.equals("EQUIPO")) {
                lblCol.setHorizontalAlignment(JLabel.CENTER);
            }
            tableHeader.add(lblCol);
        }

        // Cuerpo de la tabla (Mensaje vacío "Sin préstamos registrados.")
        JPanel tableBody = new JPanel(new GridBagLayout());
        tableBody.setOpaque(false);
        
        JLabel lblEmptyMessage = new JLabel("Sin préstamos registrados.");
        lblEmptyMessage.setFont(new Font("SansSerif", Font.PLAIN, 13));
        lblEmptyMessage.setForeground(COLOR_TEXT_MUTED);
        tableBody.add(lblEmptyMessage);

        // Ensamblar la tarjeta de la tabla
        tableCard.add(tableHeader, BorderLayout.NORTH);
        tableCard.add(tableBody, BorderLayout.CENTER);

        // 3. Agregar la tarjeta al panel principal
        gbc.gridy = 1;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(0, 0, 100, 0); // Espaciado inferior para simetría
        add(tableCard, gbc);
    }

    // Clase interna para esquinas redondeadas
    static class RoundedPanel extends JPanel {
        private final int cornerRadius;
        private final Color backgroundColor;

        public RoundedPanel(int radius, Color bgColor) {
            this.cornerRadius = radius;
            this.backgroundColor = bgColor;
            setOpaque(false); 
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D graphics = (Graphics2D) g;
            graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            graphics.setColor(backgroundColor);
            graphics.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), cornerRadius, cornerRadius));
        }
    }
}
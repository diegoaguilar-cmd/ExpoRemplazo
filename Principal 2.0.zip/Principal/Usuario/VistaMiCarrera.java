package Principal.Usuario;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class VistaMiCarrera extends JPanel {

    // Paleta de colores consistente con el Dashboard
    private static final Color COLOR_BG = new Color(11, 13, 23);         
    private static final Color COLOR_CARD_BG = new Color(20, 26, 47);    
    private static final Color COLOR_INPUT_BG = new Color(30, 37, 58);   
    private static final Color COLOR_TEXT_MUTED = new Color(110, 118, 142); 
    private static final Color COLOR_TEXT_LIGHT = new Color(240, 242, 245); 
    private static final Color COLOR_BLUE_ACCENT = new Color(0, 119, 255);
    
    // Colores para los estados de los equipos
    private static final Color COLOR_GREEN = new Color(46, 204, 113);
    private static final Color COLOR_ORANGE = new Color(230, 126, 34);

    public VistaMiCarrera() {
        setBackground(COLOR_BG);
        setLayout(new GridBagLayout());
        setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        // 1. TÍTULO DE LA SECCIÓN ("Mi Carrera")
        JLabel lblTitulo = new JLabel("Mi Carrera");
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 24));
        lblTitulo.setForeground(COLOR_TEXT_LIGHT);
        gbc.gridy = 0;
        gbc.insets = new Insets(0, 0, 20, 0);
        add(lblTitulo, gbc);

        // 2. CONTENEDOR PRINCIPAL DE LOS CAMPOS (Tarjeta exterior con bordes finos)
        RoundedPanel mainCard = new RoundedPanel(22, COLOR_CARD_BG);
        mainCard.setLayout(new GridLayout(1, 2, 20, 0));
        mainCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(30, 38, 64), 1),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        // Sub-Tarjeta Izquierda: Carrera
        RoundedPanel pnlCarrera = crearTarjetaDetalle("CARRERA", "Técnico en Computación");
        // Sub-Tarjeta Derecha: Taller
        RoundedPanel pnlTaller = crearTarjetaDetalle("TALLER", "Taller de Computación");

        mainCard.add(pnlCarrera);
        mainCard.add(pnlTaller);

        gbc.gridy = 1;
        gbc.insets = new Insets(0, 0, 35, 0);
        add(mainCard, gbc);

        // 3. SUBTÍTULO ("Equipos Autorizados para tu Carrera")
        JLabel lblSubtitulo = new JLabel("Equipos Autorizados para tu Carrera");
        lblSubtitulo.setFont(new Font("SansSerif", Font.BOLD, 16));
        lblSubtitulo.setForeground(COLOR_TEXT_LIGHT);
        gbc.gridy = 2;
        gbc.insets = new Insets(0, 0, 20, 0);
        add(lblSubtitulo, gbc);

        // 4. GRID DE TARJETAS DE EQUIPOS (Muestra hardware autorizado elegante)
        JPanel pnlEquiposGrid = new JPanel(new GridLayout(1, 3, 20, 0));
        pnlEquiposGrid.setOpaque(false);

        // Agregamos tres equipos de ejemplo que encajan perfectamente con el inventario
        pnlEquiposGrid.add(crearCardEquipo("Laptops Dell Inspiron i7", "Hardware", "Disponible", COLOR_GREEN));
        pnlEquiposGrid.add(crearCardEquipo("Módulos de Arduino Uno v3", "Electrónica", "Disponible", COLOR_GREEN));
        pnlEquiposGrid.add(crearCardEquipo("Servidor de Pruebas HP", "Redes / Servidores", "En Uso", COLOR_ORANGE));

        gbc.gridy = 3;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(0, 0, 10, 0);
        add(pnlEquiposGrid, gbc);
    }

    // Genera un bloque de visualización de datos (como Carrera o Taller en la captura)
    private RoundedPanel crearTarjetaDetalle(String titulo, String valor) {
        RoundedPanel panel = new RoundedPanel(15, COLOR_INPUT_BG);
        panel.setLayout(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        
        // Etiqueta del campo (ej: "CARRERA")
        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 10));
        lblTitulo.setForeground(COLOR_TEXT_MUTED);
        gbc.gridy = 0;
        gbc.insets = new Insets(0, 0, 8, 0);
        panel.add(lblTitulo, gbc);
        
        // Texto del valor asignado
        JLabel lblValor = new JLabel(valor);
        lblValor.setFont(new Font("SansSerif", Font.BOLD, 14));
        lblValor.setForeground(COLOR_TEXT_LIGHT);
        gbc.gridy = 1;
        gbc.insets = new Insets(0, 0, 0, 0);
        panel.add(lblValor, gbc);
        
        return panel;
    }

    // Genera una tarjeta visual de un equipo autorizado
    private RoundedPanel crearCardEquipo(String nombre, String categoria, String estado, Color colorEstado) {
        RoundedPanel card = new RoundedPanel(18, COLOR_CARD_BG);
        card.setLayout(new GridBagLayout());
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(30, 38, 64), 1),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        
        // Categoría en azul brillante
        JLabel lblCat = new JLabel(categoria.toUpperCase());
        lblCat.setFont(new Font("SansSerif", Font.BOLD, 9));
        lblCat.setForeground(COLOR_BLUE_ACCENT);
        gbc.gridy = 0;
        gbc.insets = new Insets(0, 0, 6, 0);
        card.add(lblCat, gbc);
        
        // Nombre del equipo en blanco
        JLabel lblNombre = new JLabel(nombre);
        lblNombre.setFont(new Font("SansSerif", Font.BOLD, 15));
        lblNombre.setForeground(COLOR_TEXT_LIGHT);
        gbc.gridy = 1;
        gbc.insets = new Insets(0, 0, 15, 0);
        card.add(lblNombre, gbc);
        
        // Pequeño Badge redondeado para el Estado (con color translúcido de fondo)
        Color fondoBadge = new Color(colorEstado.getRed(), colorEstado.getGreen(), colorEstado.getBlue(), 25);
        RoundedPanel badge = new RoundedPanel(10, fondoBadge);
        badge.setLayout(new GridBagLayout());
        badge.setPreferredSize(new Dimension(100, 24));
        
        JLabel lblEstado = new JLabel("• " + estado);
        lblEstado.setFont(new Font("SansSerif", Font.BOLD, 10));
        lblEstado.setForeground(colorEstado);
        badge.add(lblEstado);
        
        JPanel badgeContainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        badgeContainer.setOpaque(false);
        badgeContainer.add(badge);
        
        gbc.gridy = 2;
        gbc.insets = new Insets(0, 0, 0, 0);
        card.add(badgeContainer, gbc);
        
        return card;
    }

    // Clase interna para paneles con esquinas redondeadas
    static class RoundedPanel extends JPanel {
        private final int cornerRadius;
        private final Color backgroundColor;

        public RoundedPanel(int radius, Color bgColor) {
            this.cornerRadius = radius;
            this.backgroundColor = bgColor;
            setOpaque(false); 
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D graphics = (Graphics2D) g;
            graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            graphics.setColor(backgroundColor);
            graphics.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), cornerRadius, cornerRadius));
        }
    }
}
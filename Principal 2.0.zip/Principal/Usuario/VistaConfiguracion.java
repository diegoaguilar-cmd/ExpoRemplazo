package Principal.Usuario;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.Timer;

public class VistaConfiguracion extends JPanel {

    // Paleta de colores consistente
    private static final Color COLOR_BG = new Color(11, 13, 23);         
    private static final Color COLOR_CARD_BG = new Color(20, 26, 47);    
    private static final Color COLOR_INPUT_BG = new Color(30, 37, 58);   
    private static final Color COLOR_TEXT_MUTED = new Color(110, 118, 142); 
    private static final Color COLOR_TEXT_LIGHT = new Color(240, 242, 245); 
    
    private static final Color COLOR_BLUE_ACCENT = new Color(0, 119, 255);
    private static final Color COLOR_GREEN_SAVE = new Color(46, 204, 113);

    // Campos de Contraseña
    private final JPasswordField txtPassActual;
    private final JPasswordField txtPassNueva;
    private final JPasswordField txtPassConfirmar;

    // Botón
    private final RoundedPanel btnCambiarPass;
    private final JLabel lblTextoBoton;

    public VistaConfiguracion() {
        setBackground(COLOR_BG);
        setLayout(new GridBagLayout());
        setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        // 1. TÍTULO PRINCIPAL
        JLabel lblTitulo = new JLabel("Configuración");
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 24));
        lblTitulo.setForeground(COLOR_TEXT_LIGHT);
        gbc.gridy = 0;
        gbc.insets = new Insets(0, 0, 15, 0);
        add(lblTitulo, gbc);

        // 2. TARJETA DE NOTIFICACIONES
        RoundedPanel cardNotificaciones = new RoundedPanel(22, COLOR_CARD_BG);
        cardNotificaciones.setLayout(new GridBagLayout());
        cardNotificaciones.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        GridBagConstraints notifGbc = new GridBagConstraints();
        notifGbc.gridx = 0;
        notifGbc.fill = GridBagConstraints.HORIZONTAL;
        notifGbc.weightx = 1.0;

        // Título de Sección Notificaciones con Emoji
        JLabel lblNotifTitulo = new JLabel("🔔 Notificaciones");
        lblNotifTitulo.setFont(new Font("SansSerif", Font.BOLD, 15));
        lblNotifTitulo.setForeground(COLOR_TEXT_LIGHT);
        notifGbc.gridy = 0;
        notifGbc.insets = new Insets(0, 0, 15, 0);
        cardNotificaciones.add(lblNotifTitulo, notifGbc);

        // Separador interno
        notifGbc.gridy = 1;
        notifGbc.insets = new Insets(0, 0, 15, 0);
        cardNotificaciones.add(crearSeparador(), notifGbc);

        // Filas de los switches interactivos
        notifGbc.gridy = 2;
        notifGbc.insets = new Insets(0, 0, 15, 0);
        cardNotificaciones.add(crearFilaSwitch("Alertas de devolución próxima", "Aviso 24h antes del vencimiento", true), notifGbc);

        notifGbc.gridy = 3;
        notifGbc.insets = new Insets(0, 0, 15, 0);
        cardNotificaciones.add(crearFilaSwitch("Solicitud aprobada", "Notificarme cuando el taller apruebe", true), notifGbc);

        notifGbc.gridy = 4;
        notifGbc.insets = new Insets(0, 0, 5, 0);
        cardNotificaciones.add(crearFilaSwitch("Stock disponible", "Avisar cuando favorito esté disponible", false), notifGbc);

        gbc.gridy = 1;
        gbc.insets = new Insets(0, 0, 20, 0);
        add(cardNotificaciones, gbc);

        // 3. TARJETA DE SEGURIDAD
        RoundedPanel cardSeguridad = new RoundedPanel(22, COLOR_CARD_BG);
        cardSeguridad.setLayout(new GridBagLayout());
        cardSeguridad.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        GridBagConstraints segGbc = new GridBagConstraints();
        segGbc.gridx = 0;
        segGbc.fill = GridBagConstraints.HORIZONTAL;
        segGbc.weightx = 1.0;

        // Título de Sección Seguridad con Emoji
        JLabel lblSegTitulo = new JLabel("🔒 Seguridad");
        lblSegTitulo.setFont(new Font("SansSerif", Font.BOLD, 15));
        lblSegTitulo.setForeground(COLOR_TEXT_LIGHT);
        segGbc.gridy = 0;
        segGbc.insets = new Insets(0, 0, 15, 0);
        cardSeguridad.add(lblSegTitulo, segGbc);

        // Separador interno
        segGbc.gridy = 1;
        segGbc.insets = new Insets(0, 0, 15, 0);
        cardSeguridad.add(crearSeparador(), segGbc);

        // Formulario de Contraseñas
        txtPassActual = crearCampoPassword();
        txtPassNueva = crearCampoPassword();
        txtPassConfirmar = crearCampoPassword();

        segGbc.gridy = 2;
        segGbc.insets = new Insets(0, 0, 12, 0);
        cardSeguridad.add(crearSeccionPass("CONTRASEÑA ACTUAL", txtPassActual), segGbc);

        segGbc.gridy = 3;
        segGbc.insets = new Insets(0, 0, 12, 0);
        cardSeguridad.add(crearSeccionPass("NUEVA CONTRASEÑA", txtPassNueva), segGbc);

        segGbc.gridy = 4;
        segGbc.insets = new Insets(0, 0, 20, 0);
        cardSeguridad.add(crearSeccionPass("CONFIRMAR CONTRASEÑA", txtPassConfirmar), segGbc);

        // Botón Cambiar Contraseña
        btnCambiarPass = new RoundedPanel(12, COLOR_BLUE_ACCENT);
        btnCambiarPass.setLayout(new GridBagLayout());
        btnCambiarPass.setPreferredSize(new Dimension(180, 42));
        btnCambiarPass.setCursor(new Cursor(Cursor.HAND_CURSOR));

        lblTextoBoton = new JLabel("Cambiar Contraseña");
        lblTextoBoton.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblTextoBoton.setForeground(COLOR_TEXT_LIGHT);
        btnCambiarPass.add(lblTextoBoton);

        // Lógica interactiva del botón de contraseña
        MouseAdapter btnListener = new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                validarYCambiarContrasena();
            }
            @Override
            public void mouseEntered(MouseEvent e) {
                btnCambiarPass.setBackgroundColor(COLOR_BLUE_ACCENT.brighter());
                btnCambiarPass.repaint();
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btnCambiarPass.setBackgroundColor(COLOR_BLUE_ACCENT);
                btnCambiarPass.repaint();
            }
        };
        btnCambiarPass.addMouseListener(btnListener);
        lblTextoBoton.addMouseListener(btnListener);

        JPanel pnlBtnContainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        pnlBtnContainer.setOpaque(false);
        pnlBtnContainer.add(btnCambiarPass);

        segGbc.gridy = 5;
        segGbc.insets = new Insets(0, 0, 5, 0);
        cardSeguridad.add(pnlBtnContainer, segGbc);

        gbc.gridy = 2;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(0, 0, 20, 0);
        add(cardSeguridad, gbc);
    }

    // Valida que los campos de contraseña cumplan con las condiciones básicas
    private void validarYCambiarContrasena() {
        String actual = new String(txtPassActual.getPassword());
        String nueva = new String(txtPassNueva.getPassword());
        String confirmar = new String(txtPassConfirmar.getPassword());

        if (actual.isEmpty() || nueva.isEmpty() || confirmar.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, completa todos los campos de contraseña.", "Atención", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!nueva.equals(confirmar)) {
            JOptionPane.showMessageDialog(this, "La nueva contraseña y la confirmación no coinciden.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Si pasa las validaciones simulamos el éxito
        JOptionPane.showMessageDialog(this, "¡Tu contraseña ha sido actualizada con éxito!", "Proceso completado", JOptionPane.INFORMATION_MESSAGE);
        
        // Limpiamos los campos
        txtPassActual.setText("");
        txtPassNueva.setText("");
        txtPassConfirmar.setText("");
    }

    // Diseña un separador estético y sutil
    private JPanel crearSeparador() {
        JPanel divisor = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(new Color(30, 38, 64));
                g.drawLine(0, 0, getWidth(), 0);
            }
        };
        divisor.setPreferredSize(new Dimension(0, 1));
        divisor.setOpaque(false);
        return divisor;
    }

    // Genera una fila de configuración con título, descripción y el Toggle Switch
    private JPanel crearFilaSwitch(String titulo, String descripcion, boolean estadoInicial) {
        JPanel fila = new JPanel(new BorderLayout());
        fila.setOpaque(false);

        // Bloque de textos (Izquierda)
        JPanel pnlTextos = new JPanel(new GridLayout(2, 1, 0, 2));
        pnlTextos.setOpaque(false);

        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblTitulo.setForeground(COLOR_TEXT_LIGHT);

        JLabel lblDesc = new JLabel(descripcion);
        lblDesc.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblDesc.setForeground(COLOR_TEXT_MUTED);

        pnlTextos.add(lblTitulo);
        pnlTextos.add(lblDesc);

        // Componente Switch (Derecha)
        ToggleSwitch tSwitch = new ToggleSwitch(estadoInicial);

        fila.add(pnlTextos, BorderLayout.CENTER);
        fila.add(tSwitch, BorderLayout.EAST);

        return fila;
    }

    // Genera una sección con etiqueta superior y el campo de contraseña
    private JPanel crearSeccionPass(String titulo, JPasswordField passField) {
        JPanel pnlSection = new JPanel(new BorderLayout(0, 6));
        pnlSection.setOpaque(false);

        JLabel lbl = new JLabel(titulo);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 10));
        lbl.setForeground(COLOR_TEXT_MUTED);

        pnlSection.add(lbl, BorderLayout.NORTH);
        pnlSection.add(passField, BorderLayout.CENTER);

        return pnlSection;
    }

    // Genera un campo de contraseña diseñado profesionalmente
    private JPasswordField crearCampoPassword() {
        JPasswordField txt = new JPasswordField();
        txt.setBackground(COLOR_INPUT_BG);
        txt.setForeground(COLOR_TEXT_LIGHT); 
        txt.setFont(new Font("SansSerif", Font.PLAIN, 13));
        txt.setCaretColor(COLOR_TEXT_LIGHT);
        txt.setEchoChar('•'); // Simula los puntitos elegantes de tu diseño
        
        txt.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(30, 38, 64), 1),
                BorderFactory.createEmptyBorder(12, 16, 12, 16)
        ));
        
        // Efecto visual al ganar/perder foco
        txt.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(COLOR_BLUE_ACCENT, 1),
                        BorderFactory.createEmptyBorder(12, 16, 12, 16)
                ));
            }
            @Override
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(30, 38, 64), 1),
                        BorderFactory.createEmptyBorder(12, 16, 12, 16)
                ));
            }
        });
        
        return txt;
    }

    // --- COMPONENTE TOGGLE SWITCH ANIMADO (Creado desde cero) ---
    static class ToggleSwitch extends JPanel {
        private boolean on;
        private float location = 2.0f; // Controla la transición de animación del círculo interno
        private final Timer timer;
        private static final Color SWITCH_ON_BG = new Color(0, 119, 255);
        private static final Color SWITCH_OFF_BG = new Color(53, 59, 78);

        public ToggleSwitch(boolean defaultState) {
            this.on = defaultState;
            this.location = on ? 22.0f : 2.0f;
            setPreferredSize(new Dimension(45, 24));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setOpaque(false);

            // Timer para animar suavemente el deslizamiento del switch
            timer = new Timer(10, e -> {
                if (on) {
                    if (location < 22.0f) {
                        location += 2.5f;
                        repaint();
                    } else {
                        location = 22.0f;
                        ((Timer)e.getSource()).stop();
                    }
                } else {
                    if (location > 2.0f) {
                        location -= 2.5f;
                        repaint();
                    } else {
                        location = 2.0f;
                        ((Timer)e.getSource()).stop();
                    }
                }
            });

            addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    on = !on;
                    timer.start();
                }
            });
        } // <--- AQUÍ SE CIERRA EL CONSTRUCTOR

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Pintar cuerpo exterior del Switch
            g2.setColor(on ? SWITCH_ON_BG : SWITCH_OFF_BG);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight(), getHeight());

            // Pintar botón interno móvil (Círculo blanco)
            g2.setColor(Color.WHITE);
            g2.fillOval((int) location, 2, getHeight() - 4, getHeight() - 4);
        }
    } // <--- AQUÍ SE CIERRA LA CLASE ToggleSwitch

    // Clase interna para tarjetas con bordes redondeados
    static class RoundedPanel extends JPanel {
        private final int cornerRadius;
        private Color backgroundColor;

        public RoundedPanel(int radius, Color bgColor) {
            this.cornerRadius = radius;
            this.backgroundColor = bgColor;
            setOpaque(false); 
        }

        public void setBackgroundColor(Color color) {
            this.backgroundColor = color;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D graphics = (Graphics2D) g;
            graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            graphics.setColor(backgroundColor);
            graphics.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), cornerRadius, cornerRadius));
        }
    } // <--- AQUÍ SE CIERRA LA CLASE RoundedPanel
} // <--- AQUÍ SE CIERRA LA CLASE PRINCIPAL VistaConfiguracion
package Principal.Usuario;

import Principal.Usuario.VistaPrestamos;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.util.HashMap;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class Dashboard extends JFrame {

    // Paleta de colores base
    private static final Color COLOR_BG = new Color(11, 13, 23);
    private static final Color COLOR_SIDEBAR = new Color(15, 18, 32);
    private static final Color COLOR_CARD_BG = new Color(20, 26, 47);
    private static final Color COLOR_TEXT_MUTED = new Color(110, 118, 142);
    private static final Color COLOR_TEXT_LIGHT = new Color(240, 242, 245);

    // Color de hover estético para los botones no activos
    private static final Color COLOR_HOVER = new Color(24, 29, 47);

    // Colores de acento
    private static final Color COLOR_BLUE = new Color(41, 121, 255);
    private static final Color COLOR_RED = new Color(255, 61, 0);
    private static final Color COLOR_YELLOW = new Color(255, 196, 0);

    // Sistema de navegación (CardLayout)
    private CardLayout cardLayout;
    private JPanel contentPanel; // Contenedor que intercambia las pantallas
    private Map<String, RoundedPanel> menuButtons = new HashMap<>();
    private String seccionActiva = "Inicio";

    public Dashboard() {
        // Establecer el título del sistema
        setTitle("Instituto Técnico - Gestión de Inventario");

        // Configurar la acción de cierre por defecto
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        /* -----------------------------------------------------------------
         * CONFIGURACIÓN DE PANTALLA COMPLETA EXCLUSIVA (SIN BORDES)
         * ----------------------------------------------------------------- */
        // Elimina los bordes del sistema operativo y la barra de título superior.
        // Debe ser invocado estrictamente antes de que el frame sea visible o se inicialice por completo.
        setUndecorated(true);

        // Obtener acceso al dispositivo de pantalla predeterminado del sistema operativo
        java.awt.GraphicsEnvironment graphicsEnvironment = java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment();
        java.awt.GraphicsDevice graphicsDevice = graphicsEnvironment.getDefaultScreenDevice();

        // Validar si el sistema soporta el modo de pantalla completa exclusivo
        if (graphicsDevice.isFullScreenSupported()) {
            try {
                graphicsDevice.setFullScreenWindow(this);
            } catch (Exception exception) {
                // Alternativa de maximizado estándar en caso de fallo en el hardware/controlador gráfico
                setExtendedState(JFrame.MAXIMIZED_BOTH);
            }
        } else {
            // Alternativa por defecto si el entorno gráfico no posee soporte exclusivo
            setExtendedState(JFrame.MAXIMIZED_BOTH);
        }
        /* ----------------------------------------------------------------- */

        // Aplicar el color de fondo base y el gestor de distribución principal
        getContentPane().setBackground(COLOR_BG);
        setLayout(new BorderLayout());

        // 1. Inicializar el contenedor dinámico (CardLayout)
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setOpaque(false);

        // 2. Crear y añadir las diferentes pantallas (vistas)
        contentPanel.add(crearVistaInicio(), "Inicio");
        contentPanel.add(new VistaPrestamos(), "Mis Préstamos");
        contentPanel.add(new VistaIncidencias(), "Incidencias");
        contentPanel.add(new VistaMiPerfil(), "Mi Perfil");
        contentPanel.add(new VistaMiCarrera(), "Mi Carrera");
        contentPanel.add(crearVistaGenerica("Favoritos", "Tus equipos y herramientas marcadas como favoritas para acceso rápido."), "Favoritos");
        contentPanel.add(new VistaConfiguracion(), "Configuración");

        // 3. Crear barra lateral (Sidebar) pasándole el control de navegación
        JPanel sidebar = crearSidebar();

        // 4. Armar la ventana principal
        add(sidebar, BorderLayout.WEST);
        add(contentPanel, BorderLayout.CENTER);
    }

    // --- VISTA 1: INICIO (Tu diseño original idéntico a la imagen) ---
    private JPanel crearVistaInicio() {
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(COLOR_BG);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.weightx = 1.0;

        // Fila 1: Bienvenida
        JPanel headerPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        headerPanel.setOpaque(false);

        JLabel lblBienvenido = new JLabel("Bienvenido, REMA");
        lblBienvenido.setFont(new Font("SansSerif", Font.BOLD, 24));
        lblBienvenido.setForeground(COLOR_TEXT_LIGHT);

        JLabel lblFecha = new JLabel("martes, 14 de julio de 2026");
        lblFecha.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblFecha.setForeground(COLOR_TEXT_MUTED);

        headerPanel.add(lblBienvenido);
        headerPanel.add(lblFecha);

        gbc.gridy = 0;
        gbc.insets = new Insets(0, 0, 25, 0);
        mainPanel.add(headerPanel, gbc);

        // Fila 2: Tarjetas de Resumen
        JPanel cardsContainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        cardsContainer.setOpaque(false);

        cardsContainer.add(crearTarjetaResumen("En posesión", "0", COLOR_BLUE));
        cardsContainer.add(crearTarjetaResumen("Atrasados", "0", COLOR_RED));
        cardsContainer.add(crearTarjetaResumen("Favoritos", "0", COLOR_YELLOW));

        gbc.gridy = 1;
        gbc.insets = new Insets(0, -15, 30, 0);
        mainPanel.add(cardsContainer, gbc);

        // Fila 3: Título Sección
        JLabel lblSeccion = new JLabel("Equipos en tu Posesión");
        lblSeccion.setFont(new Font("SansSerif", Font.BOLD, 16));
        lblSeccion.setForeground(COLOR_TEXT_LIGHT);

        gbc.gridy = 2;
        gbc.insets = new Insets(0, 0, 15, 0);
        mainPanel.add(lblSeccion, gbc);

        // Fila 4: Tarjeta "Sin préstamos activos"
        JPanel emptyStateCard = crearPanelVacio();

        gbc.gridy = 3;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(0, 0, 0, 0);
        mainPanel.add(emptyStateCard, gbc);

        return mainPanel;
    }

    // --- OTRAS VISTAS (Plantilla autogenerada para el resto de botones) ---
    private JPanel crearVistaGenerica(String tituloSeccion, String descripcion) {
        JPanel view = new JPanel(new GridBagLayout());
        view.setBackground(COLOR_BG);
        view.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        // Título de la Sección
        JLabel lblTitulo = new JLabel(tituloSeccion);
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 24));
        lblTitulo.setForeground(COLOR_TEXT_LIGHT);
        gbc.gridy = 0;
        gbc.insets = new Insets(0, 0, 15, 0);
        view.add(lblTitulo, gbc);

        // Tarjeta Informativa de Contenido
        RoundedPanel bodyCard = new RoundedPanel(20, COLOR_CARD_BG);
        bodyCard.setLayout(new GridBagLayout());

        JLabel lblDesc = new JLabel("<html><center>" + descripcion + "</center></html>");
        lblDesc.setFont(new Font("SansSerif", Font.PLAIN, 14));
        lblDesc.setForeground(COLOR_TEXT_MUTED);

        GridBagConstraints gbcCard = new GridBagConstraints();
        gbcCard.insets = new Insets(50, 50, 50, 50);
        bodyCard.add(lblDesc, gbcCard);

        gbc.gridy = 1;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(0, 0, 0, 0);
        view.add(bodyCard, gbc);

        return view;
    }

    // --- BARRA LATERAL (Con lógica interactiva para cambiar de vista) ---
    private JPanel crearSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setBackground(COLOR_SIDEBAR);
        sidebar.setPreferredSize(new Dimension(220, 0));
        sidebar.setLayout(null);

        // Logo / Título
        JLabel lblLogo = new JLabel("INSTITUTO TÉCNICO");
        lblLogo.setFont(new Font("SansSerif", Font.BOLD, 12));
        lblLogo.setForeground(COLOR_TEXT_LIGHT);
        lblLogo.setBounds(20, 25, 180, 20);
        sidebar.add(lblLogo);

        JLabel lblSubLogo = new JLabel("GESTIÓN DE INVENTARIO");
        lblSubLogo.setFont(new Font("SansSerif", Font.PLAIN, 8));
        lblSubLogo.setForeground(COLOR_TEXT_MUTED);
        lblSubLogo.setBounds(20, 40, 180, 15);
        sidebar.add(lblSubLogo);

        // Botón Volver al Catálogo (Interactividad básica con hover discreto)
        RoundedPanel btnVolver = new RoundedPanel(15, COLOR_SIDEBAR);
        btnVolver.setBorder(BorderFactory.createLineBorder(COLOR_TEXT_MUTED.darker(), 1));
        btnVolver.setBounds(15, 75, 190, 35);
        btnVolver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnVolver.setLayout(new GridBagLayout());
        JLabel lblVolver = new JLabel("← Volver al Catálogo");
        lblVolver.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblVolver.setForeground(COLOR_TEXT_LIGHT);
        btnVolver.add(lblVolver);

        btnVolver.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnVolver.setBackgroundColor(COLOR_HOVER);
                btnVolver.repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btnVolver.setBackgroundColor(COLOR_SIDEBAR);
                btnVolver.repaint();
            }
        });
        sidebar.add(btnVolver);

        // Botones del Menú Lateral con detección de clics y efectos visuales de hover
        String[] items = {"Inicio", "Mis Préstamos", "Incidencias", "Mi Perfil", "Mi Carrera", "Favoritos", "Configuración"};
        int yOffset = 130;

        for (String item : items) {
            final String nombreSeccion = item;
            boolean isSelected = nombreSeccion.equals(seccionActiva);

            RoundedPanel menuItem = new RoundedPanel(10, isSelected ? COLOR_CARD_BG : COLOR_SIDEBAR);
            menuItem.setBounds(10, yOffset, 200, 35);
            menuItem.setLayout(new FlowLayout(FlowLayout.LEFT, 15, 8));
            menuItem.setCursor(new Cursor(Cursor.HAND_CURSOR));

            // Indicador/Icono visual
            JLabel lblIcon = new JLabel("▪");
            lblIcon.setForeground(isSelected ? COLOR_BLUE : COLOR_TEXT_MUTED);
            lblIcon.setFont(new Font("SansSerif", Font.BOLD, 14));
            menuItem.add(lblIcon);

            // Texto de opción
            JLabel lblText = new JLabel(nombreSeccion);
            lblText.setFont(new Font("SansSerif", isSelected ? Font.BOLD : Font.PLAIN, 12));
            lblText.setForeground(isSelected ? COLOR_TEXT_LIGHT : COLOR_TEXT_MUTED);
            menuItem.add(lblText);

            // Guardar referencia del botón en nuestro mapa para poder redibujarlos dinámicamente
            menuButtons.put(nombreSeccion, menuItem);

            // Eventos del Mouse (Hover y Click) actualizados para dar feedback visual estético
            menuItem.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    irASeccion(nombreSeccion);
                }

                @Override
                public void mouseEntered(MouseEvent e) {
                    // Si no está seleccionado, aplicamos un sutil resalto del fondo y del texto
                    if (!nombreSeccion.equals(seccionActiva)) {
                        menuItem.setBackgroundColor(COLOR_HOVER);
                        lblText.setForeground(COLOR_TEXT_LIGHT.darker());
                        menuItem.repaint();
                    }
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    // Restaurar los colores originales al salir del área
                    if (!nombreSeccion.equals(seccionActiva)) {
                        menuItem.setBackgroundColor(COLOR_SIDEBAR);
                        lblText.setForeground(COLOR_TEXT_MUTED);
                    } else {
                        menuItem.setBackgroundColor(COLOR_CARD_BG);
                        lblText.setForeground(COLOR_TEXT_LIGHT);
                    }
                    menuItem.repaint();
                }
            });

            sidebar.add(menuItem);
            yOffset += 40;
        }

        return sidebar;
    }

    // --- MÉTODO NAVEGADOR (Intercambia las pantallas y actualiza colores de botones) ---
    private void irASeccion(String nombreSeccion) {
        seccionActiva = nombreSeccion;

        // Cambiar la pantalla visible
        cardLayout.show(contentPanel, nombreSeccion);

        // Actualizar visualmente qué botón de la barra lateral se ve activo
        for (Map.Entry<String, RoundedPanel> entry : menuButtons.entrySet()) {
            String key = entry.getKey();
            RoundedPanel btn = entry.getValue();

            JLabel iconLabel = (JLabel) btn.getComponent(0);
            JLabel textLabel = (JLabel) btn.getComponent(1);

            if (key.equals(seccionActiva)) {
                btn.setBackgroundColor(COLOR_CARD_BG);
                iconLabel.setForeground(COLOR_BLUE);
                textLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
                textLabel.setForeground(COLOR_TEXT_LIGHT);
            } else {
                btn.setBackgroundColor(COLOR_SIDEBAR);
                iconLabel.setForeground(COLOR_TEXT_MUTED);
                textLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
                textLabel.setForeground(COLOR_TEXT_MUTED);
            }
            btn.repaint();
        }
    }

    // --- COMPONENTES AUXILIARES DE DISEÑO (IDÉNTICOS AL ORIGINAL) ---
    private JPanel crearTarjetaResumen(String titulo, String valor, Color colorAcento) {
        RoundedPanel card = new RoundedPanel(20, COLOR_CARD_BG);
        card.setPreferredSize(new Dimension(170, 95));
        card.setLayout(null);

        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(new Font("SansSerif", Font.PLAIN, 10));
        lblTitulo.setForeground(COLOR_TEXT_MUTED);
        lblTitulo.setBounds(15, 15, 100, 15);
        card.add(lblTitulo);

        JLabel lblNumIzq = new JLabel(valor);
        lblNumIzq.setFont(new Font("SansSerif", Font.BOLD, 28));
        lblNumIzq.setForeground(colorAcento);
        lblNumIzq.setBounds(15, 35, 50, 45);
        card.add(lblNumIzq);

        JLabel lblNumDer = new JLabel("0");
        lblNumDer.setFont(new Font("SansSerif", Font.BOLD, 14));
        lblNumDer.setForeground(COLOR_BLUE.darker().darker());
        lblNumDer.setBounds(135, 35, 30, 45);
        card.add(lblNumDer);

        return card;
    }

    private JPanel crearPanelVacio() {
        RoundedPanel panel = new RoundedPanel(20, COLOR_CARD_BG);
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.CENTER;

        JLabel lblIconBox = new JLabel("📦");
        lblIconBox.setFont(new Font("SansSerif", Font.PLAIN, 40));
        gbc.gridy = 0;
        gbc.insets = new Insets(0, 0, 15, 0);
        panel.add(lblIconBox, gbc);

        JLabel lblTitulo = new JLabel("Sin préstamos activos");
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblTitulo.setForeground(COLOR_TEXT_LIGHT);
        gbc.gridy = 1;
        gbc.insets = new Insets(0, 0, 5, 0);
        panel.add(lblTitulo);

        JLabel lblSub = new JLabel("No tienes equipos en posesión actualmente.");
        lblSub.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblSub.setForeground(COLOR_TEXT_MUTED);
        gbc.gridy = 2;
        gbc.insets = new Insets(0, 0, 0, 0);
        panel.add(lblSub, gbc);

        return panel;
    }

    // Clase auxiliar para los paneles redondeados con soporte de cambio de color dinámico
    static class RoundedPanel extends JPanel {

        private final int cornerRadius;
        private Color backgroundColor;

        public RoundedPanel(int radius, Color bgColor) {
            this.cornerRadius = radius;
            this.backgroundColor = bgColor;
            setOpaque(false);
        }

        public void setBackgroundColor(Color color) {
            this.backgroundColor = color;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D graphics = (Graphics2D) g;
            graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            graphics.setColor(backgroundColor);
            graphics.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), cornerRadius, cornerRadius));
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
            }
            new Dashboard().setVisible(true);
        });
    }
}

package Principal.Usuario;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class VistaMiPerfil extends JPanel {

    // Colores del diseño
    private static final Color COLOR_BG = new Color(11, 13, 23);         
    private static final Color COLOR_CARD_BG = new Color(20, 26, 47);    
    private static final Color COLOR_INPUT_BG = new Color(30, 37, 58);   
    private static final Color COLOR_TEXT_MUTED = new Color(110, 118, 142); 
    private static final Color COLOR_TEXT_LIGHT = new Color(240, 242, 245); 
    
    private static final Color COLOR_BLUE_BTN = new Color(0, 119, 255);
    private static final Color COLOR_GREEN_SAVE = new Color(46, 204, 113);
    private static final Color COLOR_AVATAR_BG = new Color(14, 43, 84);
    private static final Color COLOR_AVATAR_BORDER = new Color(0, 119, 255);

    // Campos de Texto
    private final JTextField txtCarnet;
    private final JTextField txtCorreo;
    private final JTextField txtTaller;
    private final JTextField txtTelefono;
    
    // Botón
    private final RoundedPanel btnEditar;
    private final JLabel lblTextoBoton;
    private boolean modoEdicion = false; 

    public VistaMiPerfil() {
        setBackground(COLOR_BG);
        setLayout(new GridBagLayout());
        setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        // 1. Título
        JLabel lblTitulo = new JLabel("Mi Perfil");
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 24));
        lblTitulo.setForeground(COLOR_TEXT_LIGHT);
        gbc.gridy = 0;
        gbc.insets = new Insets(0, 0, 20, 0);
        add(lblTitulo, gbc);

        // 2. Tarjeta contenedora
        RoundedPanel profileCard = new RoundedPanel(22, COLOR_CARD_BG);
        profileCard.setLayout(new GridBagLayout());
        profileCard.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        GridBagConstraints cardGbc = new GridBagConstraints();
        cardGbc.gridx = 0;
        cardGbc.fill = GridBagConstraints.HORIZONTAL;
        cardGbc.weightx = 1.0;

        // Avatar, Nombre, Estado
        JPanel pnlHeader = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 0));
        pnlHeader.setOpaque(false);

        JPanel avatar = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(COLOR_AVATAR_BG);
                g2.fillOval(2, 2, getWidth() - 4, getHeight() - 4);
                g2.setColor(COLOR_AVATAR_BORDER);
                g2.setStroke(new java.awt.BasicStroke(2));
                g2.drawOval(2, 2, getWidth() - 4, getHeight() - 4);
                g2.setColor(COLOR_AVATAR_BORDER);
                g2.setFont(new Font("SansSerif", Font.BOLD, 32));
                java.awt.FontMetrics fm = g2.getFontMetrics();
                int x = (getWidth() - fm.stringWidth("U")) / 2;
                int y = ((getHeight() - fm.getHeight()) / 2) + fm.getAscent();
                g2.drawString("U", x, y);
            }
        };
        avatar.setPreferredSize(new Dimension(80, 80));
        avatar.setOpaque(false);
        pnlHeader.add(avatar);

        JPanel pnlUserInfo = new JPanel(new GridLayout(2, 1, 0, 4));
        pnlUserInfo.setOpaque(false);
        
        JLabel lblUserName = new JLabel("Usuario");
        lblUserName.setFont(new Font("SansSerif", Font.BOLD, 22));
        lblUserName.setForeground(COLOR_TEXT_LIGHT);
        pnlUserInfo.add(lblUserName);

        RoundedPanel badgeActivo = new RoundedPanel(10, new Color(14, 43, 84));
        badgeActivo.setLayout(new GridBagLayout());
        badgeActivo.setPreferredSize(new Dimension(80, 22));
        JLabel lblBadge = new JLabel("• ACTIVO");
        lblBadge.setFont(new Font("SansSerif", Font.BOLD, 10));
        lblBadge.setForeground(COLOR_AVATAR_BORDER);
        badgeActivo.add(lblBadge);
        
        JPanel pnlBadgeContainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        pnlBadgeContainer.setOpaque(false);
        pnlBadgeContainer.add(badgeActivo);
        pnlUserInfo.add(pnlBadgeContainer);

        pnlHeader.add(pnlUserInfo);

        cardGbc.gridy = 0;
        cardGbc.insets = new Insets(0, 0, 25, 0);
        profileCard.add(pnlHeader, cardGbc);

        // Línea divisora
        JPanel divider = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(new Color(30, 38, 64));
                g.drawLine(0, 0, getWidth(), 0);
            }
        };
        divider.setPreferredSize(new Dimension(0, 1));
        divider.setOpaque(false);
        cardGbc.gridy = 1;
        cardGbc.insets = new Insets(0, 0, 25, 0);
        profileCard.add(divider, cardGbc);

        // Formulario
        JPanel pnlForm = new JPanel(new GridLayout(2, 2, 25, 20));
        pnlForm.setOpaque(false);

        txtCarnet = crearCampoTexto("2026-0489");
        txtCorreo = crearCampoTexto("usuario.it@instituto.edu");
        txtTaller = crearCampoTexto("Taller de Computación");
        txtTelefono = crearCampoTexto("+502 5555-1234");

        pnlForm.add(crearSeccionCampo("CARNET", txtCarnet));
        pnlForm.add(crearSeccionCampo("CORREO", txtCorreo));
        pnlForm.add(crearSeccionCampo("TALLER ASIGNADO", txtTaller));
        pnlForm.add(crearSeccionCampo("TELÉFONO", txtTelefono));

        cardGbc.gridy = 2;
        cardGbc.insets = new Insets(0, 0, 30, 0);
        profileCard.add(pnlForm, cardGbc);

        // Botón Editar
        btnEditar = new RoundedPanel(12, COLOR_BLUE_BTN);
        btnEditar.setLayout(new GridBagLayout());
        btnEditar.setPreferredSize(new Dimension(150, 42));
        btnEditar.setCursor(new Cursor(Cursor.HAND_CURSOR));

        lblTextoBoton = new JLabel("Editar Perfil");
        lblTextoBoton.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblTextoBoton.setForeground(COLOR_TEXT_LIGHT);
        btnEditar.add(lblTextoBoton);

        // Acción mejorada usando MOUSE PRESSED (Mucho más estable y seguro que mouseClicked)
        btnEditar.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                toggleModoEdicion();
            }
            @Override
            public void mouseEntered(MouseEvent e) {
                if (!modoEdicion) {
                    btnEditar.setBackgroundColor(COLOR_BLUE_BTN.brighter());
                } else {
                    btnEditar.setBackgroundColor(COLOR_GREEN_SAVE.brighter());
                }
                btnEditar.repaint();
            }
            @Override
            public void mouseExited(MouseEvent e) {
                if (!modoEdicion) {
                    btnEditar.setBackgroundColor(COLOR_BLUE_BTN);
                } else {
                    btnEditar.setBackgroundColor(COLOR_GREEN_SAVE);
                }
                btnEditar.repaint();
            }
        });

        JPanel pnlBtnContainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        pnlBtnContainer.setOpaque(false);
        pnlBtnContainer.add(btnEditar);

        cardGbc.gridy = 3;
        cardGbc.insets = new Insets(0, 0, 0, 0);
        profileCard.add(pnlBtnContainer, cardGbc);

        gbc.gridy = 1;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(0, 0, 40, 0);
        add(profileCard, gbc);
    }

    // Cambia dinámicamente los estados de los campos y del botón
    private void toggleModoEdicion() {
        modoEdicion = !modoEdicion;
        
        // Habilitar/Deshabilitar edición
        txtCarnet.setEditable(modoEdicion);
        txtCorreo.setEditable(modoEdicion);
        txtTaller.setEditable(modoEdicion);
        txtTelefono.setEditable(modoEdicion);

        if (modoEdicion) {
            lblTextoBoton.setText("Guardar Cambios");
            btnEditar.setBackgroundColor(COLOR_GREEN_SAVE);
            
            // Actualizar estilo visual a "Modo Escritura"
            actualizarEstiloCampo(txtCarnet, true);
            actualizarEstiloCampo(txtCorreo, true);
            actualizarEstiloCampo(txtTaller, true);
            actualizarEstiloCampo(txtTelefono, true);
            
            // Pone el foco directamente en el primer campo para empezar a escribir
            txtCarnet.requestFocusInWindow();
        } else {
            lblTextoBoton.setText("Editar Perfil");
            btnEditar.setBackgroundColor(COLOR_BLUE_BTN);
            
            // Regresar al estilo original "Modo Lectura"
            actualizarEstiloCampo(txtCarnet, false);
            actualizarEstiloCampo(txtCorreo, false);
            actualizarEstiloCampo(txtTaller, false);
            actualizarEstiloCampo(txtTelefono, false);
        }
        
        // Forzar a Swing a actualizarse en pantalla inmediatamente
        revalidate();
        repaint();
    }

    private JPanel crearSeccionCampo(String titulo, JTextField txtField) {
        JPanel pnlSection = new JPanel(new BorderLayout(0, 6));
        pnlSection.setOpaque(false);

        JLabel lbl = new JLabel(titulo);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 10));
        lbl.setForeground(COLOR_TEXT_MUTED);

        pnlSection.add(lbl, BorderLayout.NORTH);
        pnlSection.add(txtField, BorderLayout.CENTER);

        return pnlSection;
    }

    private JTextField crearCampoTexto(String placeholder) {
        JTextField txt = new JTextField(placeholder);
        txt.setBackground(COLOR_INPUT_BG);
        txt.setForeground(COLOR_TEXT_MUTED); 
        txt.setFont(new Font("SansSerif", Font.PLAIN, 13));
        txt.setCaretColor(COLOR_TEXT_LIGHT);
        txt.setEditable(false); 
        
        txt.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_INPUT_BG, 1),
                BorderFactory.createEmptyBorder(12, 16, 12, 16)
        ));
        
        return txt;
    }

    private void actualizarEstiloCampo(JTextField field, boolean editable) {
        if (editable) {
            field.setForeground(COLOR_TEXT_LIGHT);
            field.setCursor(new Cursor(Cursor.TEXT_CURSOR));
            field.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(COLOR_BLUE_BTN, 1), 
                    BorderFactory.createEmptyBorder(12, 16, 12, 16)
            ));
        } else {
            field.setForeground(COLOR_TEXT_MUTED);
            field.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            field.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(COLOR_INPUT_BG, 1),
                    BorderFactory.createEmptyBorder(12, 16, 12, 16)
            ));
        }
    }

    // Clase interna limpia para el panel redondeado
    static class RoundedPanel extends JPanel {
        private final int cornerRadius;
        private Color backgroundColor;

        public RoundedPanel(int radius, Color bgColor) {
            this.cornerRadius = radius;
            this.backgroundColor = bgColor;
            setOpaque(false); 
        }

        public void setBackgroundColor(Color color) {
            this.backgroundColor = color;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D graphics = (Graphics2D) g;
            graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            graphics.setColor(backgroundColor);
            graphics.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), cornerRadius, cornerRadius));
        }
    }
}
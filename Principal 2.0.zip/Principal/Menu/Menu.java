package Principal.Menu;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import java.util.*;
import java.util.List;

public class Menu extends JFrame {

    // ---------- Paleta de colores ----------
    static final Color BG_DARK = new Color(9, 12, 22);
    static final Color BG_PANEL = new Color(17, 22, 38);
    static final Color BG_CARD = new Color(24, 30, 50);
    static final Color BG_INPUT = new Color(28, 34, 54);
    static final Color ACCENT_BLUE = new Color(59, 130, 246);
    static final Color ACCENT_PURPLE = new Color(147, 88, 245);
    static final Color GREEN = new Color(74, 222, 128);
    static final Color RED = new Color(248, 113, 113);
    static final Color ORANGE = new Color(251, 191, 36);
    static final Color TEXT_WHITE = new Color(240, 242, 248);
    static final Color TEXT_GRAY = new Color(148, 163, 184);
    static final Color BORDER_COLOR = new Color(40, 47, 70);

    // ---------- Modelo de datos ----------
    static class Equipo {

        String nombre, codigo, area, ubicacion, estado;
        String nombreImagen;       // Nombre del archivo (ej: "5.png", "7.png")
        boolean esMitadIzquierda; // true = lado izquierdo, false = lado derecho
        boolean favorito = false;

        Equipo(String nombre, String codigo, String area, String ubicacion, String estado, String nombreImagen, boolean esMitadIzquierda) {
            this.nombre = nombre;
            this.codigo = codigo;
            this.area = area;
            this.ubicacion = ubicacion;
            this.estado = estado;
            this.nombreImagen = nombreImagen;
            this.esMitadIzquierda = esMitadIzquierda;
        }
    }

    private List<Equipo> equipos = new ArrayList<>();
    private List<Equipo> misPrestamos = new ArrayList<>();

    private String filtroEstado = "Todos";
    private String filtroArea = null;

    private JTextField searchField;
    private JPanel equipmentGrid;
    private JLabel resultadosLabel;
    private JPanel heroPanel;
    private JScrollPane scrollPane;
    private JPanel equipmentSection;

    private boolean sesionActiva = true;

    public Menu() {
        cargarDatosDePrueba();
        initUI();
    }

    // ================= DATOS DE PRUEBA =================
    private void cargarDatosDePrueba() {
        // Mapeado según tu carpeta de imágenes real del programa
        equipos.add(new Equipo("Torquímetro", "#MEC-020", "Mecánica", "Taller de Mecánica", "Disponible", "1.png", true));
        equipos.add(new Equipo("Manguera de Aire", "#MEC-012", "Mecánica", "Bodega", "Disponible", "1.png", false));

        equipos.add(new Equipo("Atornillador de Impacto", "#ELE-009", "Electricidad", "Taller", "Disponible", "2.png", true));
        equipos.add(new Equipo("Prensa C de Soldador", "#MEC-022", "Mecánica", "Bodega", "Disponible", "2.png", false));

        equipos.add(new Equipo("Cadena de Eslabones", "#MEC-033", "Mecánica", "Bodega", "Disponible", "3.png", true));
        equipos.add(new Equipo("Extractor de Rótulas", "#MEC-015", "Mecánica", "Taller", "Disponible", "3.png", false));

        equipos.add(new Equipo("Escáner Automotriz", "#MEC-040", "Mecánica", "Taller de Mecánica", "Disponible", "4.png", true));
        equipos.add(new Equipo("Alexómetro Mitutoyo", "#MEC-014", "Mecánica", "Bodega", "Disponible", "4.png", false));

        equipos.add(new Equipo("Juego de Puntas", "#COM-008", "Computación", "CB", "Disponible", "5.png", true));
        equipos.add(new Equipo("Manómetro Dual", "#MEC-042", "Mecánica", "Bodega", "Disponible", "5.png", false));

        equipos.add(new Equipo("Calibrador Vernier Digital", "#MEC-009", "Mecánica", "Bodega", "Disponible", "6.png", true));
        equipos.add(new Equipo("Calibrador de Profundidad", "#MEC-010", "Mecánica", "Bodega", "Disponible", "6.png", false));

        equipos.add(new Equipo("Fuente de Poder", "#ELE-005", "Electricidad", "Taller", "Mantenimiento", "7.png", true));
        equipos.add(new Equipo("Barreno Milwaukee de raíz 1/2", "#MEC-0016", "Mecánica", "Bodega", "Disponible", "7.png", false));

        equipos.add(new Equipo("Amoladora Angular Chica", "#MEC-060", "Mecánica", "Bodega", "Disponible", "8.png", true));
        equipos.add(new Equipo("Amoladora Esmeril Bosch", "#MEC-061", "Mecánica", "Taller", "Disponible", "8.png", false));

        equipos.add(new Equipo("Sierra de Calar Milwaukee", "#MEC-070", "Mecánica", "Bodega", "Disponible", "9.png", true));
        equipos.add(new Equipo("Juego de Alicates", "#ELE-012", "Electricidad", "Taller", "Disponible", "9.png", false));

        equipos.add(new Equipo("Juego de Dados Cortos", "#MEC-080", "Mecánica", "Taller", "Disponible", "10.png", true));
        equipos.add(new Equipo("Juego de Dados de Impacto", "#MEC-081", "Mecánica", "Bodega", "En Uso", "10.png", false));

        // --- AGREGANDO LAS IMÁGENES DE LA 11 A LA 16 ---
        equipos.add(new Equipo("Torre de Soporte Mecánico", "#MEC-090", "Mecánica", "Taller", "Disponible", "11.png", true));
        equipos.add(new Equipo("Torre de Soporte Reforzada", "#MEC-091", "Mecánica", "Taller", "Disponible", "11.png", false));

        equipos.add(new Equipo("Careta para Soldar", "#MEC-095", "Mecánica", "Taller de Soldadura", "Disponible", "12.png", true));
        equipos.add(new Equipo("Protector Facial Transparente", "#MEC-096", "Mecánica", "Bodega", "Disponible", "12.png", false));

        equipos.add(new Equipo("Llave de Cruz 14\"", "#MEC-100", "Mecánica", "Bodega", "Disponible", "13.png", true));
        equipos.add(new Equipo("Prensa G Profesional", "#MEC-101", "Mecánica", "Taller", "Disponible", "13.png", false));

        equipos.add(new Equipo("Manguera de Aire Neumática", "#MEC-105", "Mecánica", "Bodega", "Disponible", "14.png", true));
        equipos.add(new Equipo("Martillo de Bola", "#MEC-106", "Mecánica", "Taller", "Disponible", "14.png", false));

        equipos.add(new Equipo("Cinta Métrica / Flexómetro", "#MEC-110", "Mecánica", "Bodega", "Disponible", "15.png", true));
        equipos.add(new Equipo("Serrucho para Madera", "#MEC-111", "Mecánica", "Bodega", "Disponible", "15.png", false));

// La 16 solo tiene una herramienta en medio, así que la registramos una sola vez
        equipos.add(new Equipo("Galga Calibradora de Alambre", "#ELE-080", "Electricidad", "Taller", "Disponible", "16.png", true));
    }

    // ================= INTERFAZ =================
    private void initUI() {
        setUndecorated(true);
        setTitle("Instituto Técnico - Gestión de Inventario");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setSize(screenSize);
        setLocation(0, 0);
        setMinimumSize(new Dimension(1000, 700));

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG_DARK);

        root.add(buildTopBar(), BorderLayout.NORTH);

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBackground(BG_DARK);
        content.setBorder(new EmptyBorder(0, 0, 40, 0));

        heroPanel = buildHero();
        content.add(heroPanel);
        content.add(buildAreas());
        equipmentSection = buildEquipmentSection();
        content.add(equipmentSection);

        scrollPane = new JScrollPane(content);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.setBackground(BG_DARK);
        scrollPane.getViewport().setBackground(BG_DARK);

        root.add(scrollPane, BorderLayout.CENTER);

        setContentPane(root);
        refreshEquipmentGrid();
    }

    private JPanel buildTopBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(BG_PANEL);
        bar.setBorder(new CompoundBorder(
                new MatteBorder(0, 0, 1, 0, BORDER_COLOR),
                new EmptyBorder(12, 24, 12, 24)));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 0));
        left.setOpaque(false);

        JLabel logo = new JLabel("💻  INSTITUTO TÉCNICO");
        logo.setFont(new Font("SansSerif", Font.BOLD, 15));
        logo.setForeground(TEXT_WHITE);

        searchField = new JTextField(28);
        styleInput(searchField, "Buscar herramienta o código...");
        searchField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                refreshEquipmentGrid();
            }
        });

        JButton inicioBtn = flatButton("← Inicio", TEXT_GRAY, null);
        inicioBtn.addActionListener(e -> scrollToTop());

        left.add(logo);
        left.add(searchField);
        left.add(inicioBtn);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        right.setOpaque(false);

        JButton cuentaBtn = pillButton("👤 Mi Cuenta", BG_INPUT, TEXT_WHITE);
        cuentaBtn.addActionListener(e -> mostrarMiCuenta());

        JButton adminBtn = pillButton("⚙ Admin", BG_INPUT, TEXT_WHITE);
        adminBtn.addActionListener(e -> mostrarAdmin());

        JButton logoutBtn = pillButton("Cerrar sesión", new Color(60, 20, 25), RED);
        logoutBtn.addActionListener(e -> cerrarSesion());

        right.add(cuentaBtn);
        right.add(adminBtn);
        right.add(logoutBtn);

        bar.add(left, BorderLayout.WEST);
        bar.add(right, BorderLayout.EAST);
        return bar;
    }
// Agrega estas variables globales arriba en tu clase (debajo de "private JPanel equipmentSection;")
    private int currentImgIndex = 0;
    private Image currentBgImage = null;
    private Image nextBgImage = null;
    private float transitionAlpha = 1.0f; // Controla el desvanecido
    private javax.swing.Timer slideshowTimer;
    private javax.swing.Timer fadeTimer;
    private final String[] imagenesSlideshow = {"Meca.jpg", "Electri.png", "Com.png"};

private JPanel buildHero() {
        HeroPanel hero = new HeroPanel();
        hero.setLayout(new BoxLayout(hero, BoxLayout.Y_AXIS));
        // Ajustamos los márgenes originales
        hero.setBorder(new EmptyBorder(35, 50, 25, 50));

        // 1. Etiqueta superior
        JLabel badge = new JLabel("● SISTEMA DE GESTIÓN DE INVENTARIO");
        badge.setForeground(ACCENT_BLUE);
        badge.setFont(new Font("SansSerif", Font.BOLD, 11));
        badge.setBorder(new EmptyBorder(5, 12, 5, 12));
        badge.setOpaque(true);
        badge.setBackground(new Color(30, 41, 70, 180));
        
        JPanel badgeWrap = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        badgeWrap.setOpaque(false);
        badgeWrap.add(badge);

        // 2. Títulos
        JLabel title1 = new JLabel("Préstamo de Equipos");
        title1.setForeground(TEXT_WHITE);
        title1.setFont(new Font("SansSerif", Font.BOLD, 34));

        JLabel title2 = new JLabel("y Herramientas");
        title2.setForeground(ACCENT_PURPLE);
        title2.setFont(new Font("SansSerif", Font.BOLD, 34));

        // 3. Subtítulo con tamaño controlado
        JLabel subtitle = new JLabel("<html><div style='width:550px;'>Plataforma institucional para consulta de "
                + "disponibilidad, solicitud de préstamos y gestión de devoluciones.</div></html>");
        subtitle.setForeground(TEXT_WHITE); 
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 13));
        subtitle.setBorder(new EmptyBorder(10, 0, 15, 0));

        // 4. Fila de Botones
        JPanel buttonsRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        buttonsRow.setOpaque(false);

        JButton explorarBtn = pillButton("Explorar Equipos  →", ACCENT_BLUE, Color.WHITE);
        explorarBtn.addActionListener(e -> scrollToEquipment());

        JButton misPrestamosBtn = pillButton("Mis Préstamos", BG_INPUT, TEXT_WHITE);
        misPrestamosBtn.addActionListener(e -> mostrarMisPrestamos());

        buttonsRow.add(explorarBtn);
        buttonsRow.add(misPrestamosBtn);

        // 5. Fila de Estadísticas original
        JPanel statsRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 35, 0));
        statsRow.setOpaque(false);
        statsRow.setBorder(new EmptyBorder(20, 0, 0, 0));
        statsRow.add(statBox(String.valueOf(contar("Disponible")), "DISPONIBLES", GREEN));
        statsRow.add(statBox(String.valueOf(contar("En Uso")), "EN USO", RED));
        statsRow.add(statBox(String.valueOf(contar("Mantenimiento")), "MANTENIMIENTO", TEXT_GRAY));
        statsRow.add(statBox(String.valueOf(equipos.size()), "TOTAL EQUIPOS", ACCENT_BLUE));

        // Ensamblar todo en orden
        hero.add(badgeWrap);
        hero.add(Box.createVerticalStrut(10));
        hero.add(title1);
        hero.add(title2);
        hero.add(subtitle);
        hero.add(buttonsRow);
        hero.add(statsRow);
        
        return hero;
    }
// Carga la primera imagen de forma segura al iniciar la aplicación

    private void cargarImagenInicial() {
        try {
            File file = new File("imagenes/" + imagenesSlideshow[currentImgIndex]);
            if (file.exists()) {
                currentBgImage = ImageIO.read(file);
            }
        } catch (Exception ignored) {
        }
    }

// Ejecuta la transición de desvanecido suave ("fade in") entre imágenes
    private void iniciarTransicionFondo(JPanel panel) {
        try {
            int nextIndex = (currentImgIndex + 1) % imagenesSlideshow.length;
            File file = new File("imagenes/" + imagenesSlideshow[nextIndex]);

            if (file.exists()) {
                nextBgImage = ImageIO.read(file);
                transitionAlpha = 0.0f; // Empezamos totalmente invisible

                if (fadeTimer != null) {
                    fadeTimer.stop();
                }

                // Timer rápido para aumentar la opacidad gradualmente (cada 30ms)
                fadeTimer = new javax.swing.Timer(30, evt -> {
                    transitionAlpha += 0.05f; // Velocidad de la transición
                    if (transitionAlpha >= 1.0f) {
                        transitionAlpha = 1.0f;
                        currentBgImage = nextBgImage; // La siguiente se convierte en la actual
                        nextBgImage = null;
                        currentImgIndex = nextIndex;
                        fadeTimer.stop();
                    }
                    panel.repaint();
                });
                fadeTimer.start();
            }
        } catch (Exception ignored) {
        }
    }

    private JPanel statBox(String number, String label, Color color) {
        JPanel box = new JPanel();
        box.setOpaque(false);
        box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));
        JLabel num = new JLabel(number);
        num.setFont(new Font("SansSerif", Font.BOLD, 26));
        num.setForeground(color);
        num.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel lab = new JLabel(label);
        lab.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lab.setForeground(TEXT_GRAY);
        lab.setAlignmentX(Component.LEFT_ALIGNMENT);
        box.add(num);
        box.add(lab);
        return box;
    }

    private long contar(String estado) {
        return equipos.stream().filter(e -> e.estado.equals(estado)).count();
    }

    private JPanel buildAreas() {
        JPanel wrap = new JPanel();
        wrap.setLayout(new BoxLayout(wrap, BoxLayout.Y_AXIS));
        wrap.setBackground(BG_DARK);
        wrap.setBorder(new EmptyBorder(10, 50, 20, 50));
        wrap.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel title = new JLabel("Áreas de Equipos");
        title.setForeground(TEXT_WHITE);
        title.setFont(new Font("SansSerif", Font.BOLD, 18));
        title.setBorder(new EmptyBorder(0, 0, 12, 0));
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        row.setOpaque(false);
        row.setAlignmentX(Component.LEFT_ALIGNMENT);

        row.add(areaCard("💻", "Computación", ACCENT_BLUE));
        row.add(areaCard("⚡", "Electricidad", ORANGE));
        row.add(areaCard("⚙", "Mecánica", new Color(180, 90, 50)));

        wrap.add(title);
        wrap.add(row);
        return wrap;
    }

    private JPanel areaCard(String icon, String area, Color color) {
        long total = equipos.stream().filter(e -> e.area.equals(area)).count();
        long disp = equipos.stream().filter(e -> e.area.equals(area) && e.estado.equals("Disponible")).count();

        RoundedPanel card = new RoundedPanel(14, BG_CARD);
        card.setLayout(new BorderLayout(12, 0));
        card.setBorder(new EmptyBorder(14, 16, 14, 22));
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));
        card.setPreferredSize(new Dimension(240, 64));

        JLabel iconLbl = new JLabel(icon);
        iconLbl.setFont(new Font("SansSerif", Font.PLAIN, 20));
        iconLbl.setOpaque(true);
        iconLbl.setBackground(color.darker());
        iconLbl.setHorizontalAlignment(SwingConstants.CENTER);
        iconLbl.setPreferredSize(new Dimension(38, 38));

        JPanel textBox = new JPanel();
        textBox.setOpaque(false);
        textBox.setLayout(new BoxLayout(textBox, BoxLayout.Y_AXIS));
        JLabel nameLbl = new JLabel(area);
        nameLbl.setForeground(TEXT_WHITE);
        nameLbl.setFont(new Font("SansSerif", Font.BOLD, 13));
        JLabel countLbl = new JLabel(disp + " / " + total + " disponibles");
        countLbl.setForeground(TEXT_GRAY);
        countLbl.setFont(new Font("SansSerif", Font.PLAIN, 11));
        textBox.add(nameLbl);
        textBox.add(countLbl);

        JLabel badge = new JLabel(String.valueOf(total));
        badge.setForeground(Color.WHITE);
        badge.setFont(new Font("SansSerif", Font.BOLD, 13));
        badge.setOpaque(true);
        badge.setBackground(color);
        badge.setHorizontalAlignment(SwingConstants.CENTER);
        badge.setPreferredSize(new Dimension(28, 28));

        card.add(iconLbl, BorderLayout.WEST);
        card.add(textBox, BorderLayout.CENTER);
        card.add(badge, BorderLayout.EAST);

        card.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                filtroArea = area;
                filtroEstado = "Todos";
                refreshEquipmentGrid();
                scrollToEquipment();
            }

            public void mouseEntered(MouseEvent e) {
                card.setBackground(BG_INPUT);
            }

            public void mouseExited(MouseEvent e) {
                card.setBackground(BG_CARD);
            }
        });

        return card;
    }

    private JPanel buildEquipmentSection() {
        JPanel wrap = new JPanel();
        wrap.setLayout(new BoxLayout(wrap, BoxLayout.Y_AXIS));
        wrap.setBackground(BG_DARK);
        wrap.setBorder(new EmptyBorder(10, 50, 40, 50));
        wrap.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.setAlignmentX(Component.LEFT_ALIGNMENT);
        header.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

        resultadosLabel = new JLabel();
        resultadosLabel.setForeground(TEXT_WHITE);
        resultadosLabel.setFont(new Font("SansSerif", Font.BOLD, 18));

        JPanel tabs = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        tabs.setOpaque(false);
        String[] estados = {"Todos", "Disponibles", "En Uso"};
        for (String estado : estados) {
            JButton tabBtn = pillButton(estado, estado.equals(filtroEstado) ? ACCENT_BLUE : BG_INPUT, TEXT_WHITE);
            tabBtn.addActionListener(e -> {
                filtroEstado = estado;
                filtroArea = null;
                refreshEquipmentGrid();
            });
            tabs.add(tabBtn);
        }

        header.add(resultadosLabel, BorderLayout.WEST);
        header.add(tabs, BorderLayout.EAST);

        // Cambiado a 4 columnas para que quepan mejor las imágenes estilizadas
        equipmentGrid = new JPanel(new GridLayout(0, 4, 18, 18));
        equipmentGrid.setOpaque(false);
        equipmentGrid.setBorder(new EmptyBorder(18, 0, 0, 0));
        equipmentGrid.setAlignmentX(Component.LEFT_ALIGNMENT);

        wrap.add(header);
        wrap.add(equipmentGrid);
        return wrap;
    }

    private void refreshEquipmentGrid() {
        equipmentGrid.removeAll();
        String query = searchField != null ? searchField.getText().toLowerCase().trim() : "";
        boolean placeholderActive = query.equals("buscar herramienta o código...");

        List<Equipo> filtrados = new ArrayList<>();
        for (Equipo eq : equipos) {
            boolean matchEstado = filtroEstado.equals("Todos")
                    || (filtroEstado.equals("Disponibles") && eq.estado.equals("Disponible"))
                    || (filtroEstado.equals("En Uso") && eq.estado.equals("En Uso"));
            boolean matchArea = filtroArea == null || eq.area.equals(filtroArea);
            boolean matchQuery = placeholderActive || query.isEmpty()
                    || eq.nombre.toLowerCase().contains(query)
                    || eq.codigo.toLowerCase().contains(query);
            if (matchEstado && matchArea && matchQuery) {
                filtrados.add(eq);
            }
        }

        resultadosLabel.setText("Todos los Equipos  " + filtrados.size() + " resultados"
                + (filtroArea != null ? "  • " + filtroArea : ""));

        for (Equipo eq : filtrados) {
            equipmentGrid.add(crearTarjetaEquipo(eq));
        }

        equipmentGrid.revalidate();
        equipmentGrid.repaint();
    }

    // ================= PROCESAMIENTO Y RECORTE DE IMÁGENES =================
    private JPanel crearTarjetaEquipo(Equipo eq) {
        RoundedPanel card = new RoundedPanel(14, BG_CARD);
        card.setLayout(new BorderLayout());

        // --- CONTENEDOR DE LA IMAGEN ---
        JPanel imgArea = new JPanel(new BorderLayout());
        imgArea.setBackground(Color.WHITE); // Fondo blanco limpio para contrastar el PNG
        imgArea.setPreferredSize(new Dimension(100, 140));

        // Intentamos cargar y recortar la imagen del equipo
        JLabel imageLabel = new JLabel();
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);

        try {
            File file = new File("imagenes/" + eq.nombreImagen);
            if (file.exists()) {
                BufferedImage imgCompleta = ImageIO.read(file);

                // Dividir exactamente a la mitad horizontal
                int mitadAncho = imgCompleta.getWidth() / 2;
                int alto = imgCompleta.getHeight();
                int inicioX = eq.esMitadIzquierda ? 0 : mitadAncho;

                // Recortamos la porción en memoria
                BufferedImage porcion = imgCompleta.getSubimage(inicioX, 0, mitadAncho, alto);

                // Escalar con suavizado de alta calidad a un tamaño uniforme de tarjeta
                Image escalada = porcion.getScaledInstance(180, 110, Image.SCALE_SMOOTH);
                imageLabel.setIcon(new ImageIcon(escalada));
            } else {
                // Fallback si no encuentra el archivo físico
                imageLabel.setText("⚠️ No encontrada");
                imageLabel.setForeground(Color.DARK_GRAY);
                imgArea.setBackground(new Color(60, 66, 88));
            }
        } catch (Exception ex) {
            imageLabel.setText("❌ Error");
            imgArea.setBackground(new Color(60, 66, 88));
        }

        imgArea.add(imageLabel, BorderLayout.CENTER);

        // --- BADGES DE ESTADO (Flotan encima de la imagen) ---
        JLabel estadoBadge = new JLabel("  ● " + eq.estado + "  ");
        estadoBadge.setOpaque(true);
        Color estadoColor = eq.estado.equals("Disponible") ? new Color(20, 60, 40)
                : eq.estado.equals("En Uso") ? new Color(70, 25, 25) : new Color(70, 55, 20);
        Color estadoTextColor = eq.estado.equals("Disponible") ? GREEN
                : eq.estado.equals("En Uso") ? RED : ORANGE;
        estadoBadge.setBackground(estadoColor);
        estadoBadge.setForeground(estadoTextColor);
        estadoBadge.setFont(new Font("SansSerif", Font.BOLD, 10));
        estadoBadge.setBorder(new EmptyBorder(3, 4, 3, 4));

        JPanel topRow = new JPanel(new BorderLayout());
        topRow.setOpaque(false);
        topRow.setBorder(new EmptyBorder(8, 8, 0, 8));
        JPanel badgeWrap = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        badgeWrap.setOpaque(false);
        badgeWrap.add(estadoBadge);

        JButton favBtn = new JButton(eq.favorito ? "★" : "☆");
        favBtn.setFont(new Font("SansSerif", Font.PLAIN, 16));
        favBtn.setForeground(eq.favorito ? ORANGE : Color.WHITE);
        favBtn.setBackground(new Color(0, 0, 0, 120));
        favBtn.setBorder(new EmptyBorder(2, 8, 2, 8));
        favBtn.setFocusPainted(false);
        favBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        favBtn.addActionListener(e -> {
            eq.favorito = !eq.favorito;
            favBtn.setText(eq.favorito ? "★" : "☆");
            favBtn.setForeground(eq.favorito ? ORANGE : Color.WHITE);
        });

        topRow.add(badgeWrap, BorderLayout.WEST);
        topRow.add(favBtn, BorderLayout.EAST);

        // Colocamos los botones superiores flotando sobre la sección gráfica
        JPanel layeredImgContainer = new JPanel(new BorderLayout());
        layeredImgContainer.setOpaque(false);
        layeredImgContainer.add(topRow, BorderLayout.NORTH);
        layeredImgContainer.add(imgArea, BorderLayout.CENTER);

        // --- SECCIÓN DE DETALLES (INFO) ---
        JPanel info = new JPanel();
        info.setOpaque(false);
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
        info.setBorder(new EmptyBorder(10, 12, 12, 12));

        JLabel areaLbl = new JLabel("• " + eq.area);
        areaLbl.setForeground(TEXT_GRAY);
        areaLbl.setFont(new Font("SansSerif", Font.PLAIN, 10));

        JLabel nombreLbl = new JLabel(eq.nombre);
        nombreLbl.setForeground(TEXT_WHITE);
        nombreLbl.setFont(new Font("SansSerif", Font.BOLD, 14));
        nombreLbl.setBorder(new EmptyBorder(4, 0, 4, 0));

        JPanel bottomRow = new JPanel(new BorderLayout());
        bottomRow.setOpaque(false);
        JLabel codigoLbl = new JLabel(eq.codigo);
        codigoLbl.setForeground(ACCENT_BLUE);
        codigoLbl.setFont(new Font("SansSerif", Font.PLAIN, 11));
        JLabel ubicacionLbl = new JLabel("📍 " + eq.ubicacion);
        ubicacionLbl.setForeground(TEXT_GRAY);
        ubicacionLbl.setFont(new Font("SansSerif", Font.PLAIN, 11));
        bottomRow.add(codigoLbl, BorderLayout.WEST);
        bottomRow.add(ubicacionLbl, BorderLayout.EAST);

        JButton accionBtn = pillButton(
                eq.estado.equals("Disponible") ? "Solicitar Préstamo" : "No Disponible",
                eq.estado.equals("Disponible") ? ACCENT_BLUE : BG_INPUT,
                Color.WHITE);
        accionBtn.setEnabled(eq.estado.equals("Disponible"));
        accionBtn.addActionListener(e -> solicitarPrestamo(eq, accionBtn));

        JPanel accionWrap = new JPanel(new BorderLayout());
        accionWrap.setOpaque(false);
        accionWrap.setBorder(new EmptyBorder(10, 0, 0, 0));
        accionWrap.add(accionBtn, BorderLayout.CENTER);

        info.add(areaLbl);
        info.add(nombreLbl);
        info.add(bottomRow);
        info.add(info.add(accionWrap));

        card.add(layeredImgContainer, BorderLayout.NORTH);
        card.add(info, BorderLayout.CENTER);
        return card;
    }

    // ================= ACCIONES =================
    private void solicitarPrestamo(Equipo eq, JButton btn) {
        int r = JOptionPane.showConfirmDialog(this,
                "¿Deseas solicitar el préstamo de:\n\n" + eq.nombre + " (" + eq.codigo + ")?",
                "Confirmar solicitud", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (r == JOptionPane.YES_OPTION) {
            eq.estado = "En Uso";
            misPrestamos.add(eq);
            JOptionPane.showMessageDialog(this,
                    "Solicitud registrada. Puedes ver el detalle en 'Mis Préstamos'.",
                    "Préstamo solicitado", JOptionPane.INFORMATION_MESSAGE);
            refreshFullView();
        }
    }

    private void mostrarMisPrestamos() {
        if (misPrestamos.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Aún no tienes préstamos activos.",
                    "Mis Préstamos", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        StringBuilder sb = new StringBuilder("Préstamos activos:\n\n");
        for (Equipo e : misPrestamos) {
            sb.append("• ").append(e.nombre).append(" (").append(e.codigo).append(")\n");
        }
        int r = JOptionPane.showConfirmDialog(this, sb.toString() + "\n¿Deseas devolver alguno ahora?",
                "Mis Préstamos", JOptionPane.YES_NO_OPTION);
        if (r == JOptionPane.YES_OPTION) {
            devolverEquipo();
        }
    }

    private void devolverEquipo() {
        if (misPrestamos.isEmpty()) {
            return;
        }
        String[] nombres = misPrestamos.stream().map(e -> e.nombre + " (" + e.codigo + ")").toArray(String[]::new);
        String seleccion = (String) JOptionPane.showInputDialog(this, "Selecciona el equipo a devolver:",
                "Devolver equipo", JOptionPane.PLAIN_MESSAGE, null, nombres, nombres[0]);
        if (seleccion != null) {
            Equipo aDevolver = misPrestamos.stream()
                    .filter(e -> (e.nombre + " (" + e.codigo + ")").equals(seleccion))
                    .findFirst().orElse(null);
            if (aDevolver != null) {
                aDevolver.estado = "Disponible";
                misPrestamos.remove(aDevolver);
                JOptionPane.showMessageDialog(this, "Devolución registrada correctamente.");
                refreshFullView();
            }
        }
    }

    private void mostrarMiCuenta() {
        JOptionPane.showMessageDialog(this,
                "Usuario: Estudiante\nPréstamos activos: " + misPrestamos.size(),
                "Mi Cuenta", JOptionPane.INFORMATION_MESSAGE);
    }

    private void mostrarAdmin() {
        JOptionPane.showMessageDialog(this,
                "Panel de administración\n(Aquí se conectaría el módulo de administración del inventario)",
                "Admin", JOptionPane.INFORMATION_MESSAGE);
    }

    private void cerrarSesion() {
        int r = JOptionPane.showConfirmDialog(this, "¿Deseas cerrar sesión?",
                "Cerrar sesión", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (r == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    private void scrollToEquipment() {
        SwingUtilities.invokeLater(() -> {
            Rectangle rect = equipmentSection.getBounds();
            Rectangle target = new Rectangle(rect.x, rect.y, 10, 10);
            equipmentSection.scrollRectToVisible(target);
        });
    }

    private void scrollToTop() {
        scrollPane.getViewport().setViewPosition(new Point(0, 0));
    }

    private void refreshFullView() {
        getContentPane().removeAll();
        initUI();
        revalidate();
        repaint();
    }

    // ================= COMPONENTES REUTILIZABLES =================
    private void styleInput(JTextField field, String placeholder) {
        field.setText(placeholder);
        field.setForeground(TEXT_GRAY);
        field.setBackground(BG_INPUT);
        field.setCaretColor(Color.WHITE);
        field.setBorder(new CompoundBorder(new LineBorder(BORDER_COLOR, 1, true), new EmptyBorder(6, 12, 6, 12)));
        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (field.getText().equals(placeholder)) {
                    field.setText("");
                    field.setForeground(Color.WHITE);
                }
            }

            public void focusLost(FocusEvent e) {
                if (field.getText().isEmpty()) {
                    field.setText(placeholder);
                    field.setForeground(TEXT_GRAY);
                }
            }
        });
    }

    private JButton pillButton(String text, Color bg, Color fg) {
        JButton btn = new JButton(text) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 18, 18);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setForeground(fg);
        btn.setBackground(bg);
        btn.setFont(new Font("SansSerif", Font.BOLD, 12));
        btn.setBorder(new EmptyBorder(9, 18, 9, 18));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private JButton flatButton(String text, Color fg, Color bg) {
        JButton btn = new JButton(text);
        btn.setForeground(fg);
        btn.setContentAreaFilled(bg != null);
        if (bg != null) {
            btn.setBackground(bg);
        }
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setFont(new Font("SansSerif", Font.PLAIN, 12));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    static class RoundedPanel extends JPanel {

        private int radius;

        RoundedPanel(int radius, Color bg) {
            this.radius = radius;
            setOpaque(false);
            setBackground(bg);
        }

        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), radius, radius));
            g2.dispose();
            super.paintComponent(g);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
            }
            new Menu().setVisible(true);
        });
    }

    /**
     * Panel con imagen de fondo adaptativa y filtro azul oscuro
     */
    static class HeroPanel extends JPanel {

        private Image currentBgImage = null;
        private Image nextBgImage = null;
        private float transitionAlpha = 1.0f;
        private int currentImgIndex = 0;
        private javax.swing.Timer slideshowTimer;
        private javax.swing.Timer fadeTimer;

        // Corregimos los nombres y extensiones reales de tus archivos
        private final String[] imagenesSlideshow = {"Meca.jpg", "Electri.jpg", "Com.png"};

        public HeroPanel() {
            setOpaque(false);
            // Fijamos la altura máxima del panel para que el diseño no se corra hacia abajo
            setPreferredSize(new Dimension(1200, 380));
            setMinimumSize(new Dimension(100, 380));
            setMaximumSize(new Dimension(9999, 380));

            cargarImagenInicial();
            iniciarSlideshow();
        }

        private void cargarImagenInicial() {
            currentBgImage = intentarCargarImagen(imagenesSlideshow[currentImgIndex]);
        }

        private Image intentarCargarImagen(String nombre) {
            // Buscamos directamente en tu carpeta de imágenes
            String[] rutasPosibles = {"imagenes/" + nombre, "src/imagenes/" + nombre};
            for (String ruta : rutasPosibles) {
                File file = new File(ruta);
                if (file.exists()) {
                    try {
                        return ImageIO.read(file);
                    } catch (Exception e) {
                        System.out.println("❌ Error al leer la imagen: " + ruta);
                    }
                }
            }

            // Si falla por la extensión (.jpg vs .png), intentamos buscar con la otra extensión automáticamente
            String alternativa = nombre.endsWith(".jpg") ? nombre.replace(".jpg", ".png") : nombre.replace(".png", ".jpg");
            for (String ruta : rutasPosibles) {
                File file = new File(ruta.replace(nombre, alternativa));
                if (file.exists()) {
                    try {
                        return ImageIO.read(file);
                    } catch (Exception e) {
                    }
                }
            }
            return null;
        }

        private void iniciarSlideshow() {
            if (slideshowTimer != null) {
                slideshowTimer.stop();
            }

            // Cada 5 segundos hace el cambio poco a poco
            slideshowTimer = new javax.swing.Timer(5000, e -> {
                int nextIndex = (currentImgIndex + 1) % imagenesSlideshow.length;
                Image proxima = intentarCargarImagen(imagenesSlideshow[nextIndex]);

                if (proxima != null) {
                    nextBgImage = proxima;
                    transitionAlpha = 0.0f;

                    if (fadeTimer != null) {
                        fadeTimer.stop();
                    }

                    fadeTimer = new javax.swing.Timer(25, evt -> {
                        transitionAlpha += 0.04f; // Velocidad del desvanecido suave
                        if (transitionAlpha >= 1.0f) {
                            transitionAlpha = 1.0f;
                            currentBgImage = nextBgImage;
                            nextBgImage = null;
                            currentImgIndex = nextIndex;
                            fadeTimer.stop();
                        }
                        repaint();
                    });
                    fadeTimer.start();
                }
            });
            slideshowTimer.start();
        }

        public void detenerTimers() {
            if (slideshowTimer != null) {
                slideshowTimer.stop();
            }
            if (fadeTimer != null) {
                fadeTimer.stop();
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);

            // Fondo base oscuro por defecto
            g2.setColor(new Color(9, 12, 22));
            g2.fillRect(0, 0, getWidth(), getHeight());

            // Dibujar imagen de fondo actual
            if (currentBgImage != null) {
                dibujarImagenAjustada(g2, currentBgImage, 1.0f);
            }

            // Dibujar la transición de la siguiente imagen
            if (nextBgImage != null && transitionAlpha < 1.0f) {
                dibujarImagenAjustada(g2, nextBgImage, transitionAlpha);
            }

            // Capa azulada semitransparente (tinte original para que las letras resalten)
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1.0f));
            g2.setColor(new Color(9, 12, 22, 210));
            g2.fillRect(0, 0, getWidth(), getHeight());

            g2.dispose();
            super.paintComponent(g);
        }

        private void dibujarImagenAjustada(Graphics2D g2, Image img, float alpha) {
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));
            int imgW = img.getWidth(null);
            int imgH = img.getHeight(null);
            if (imgW > 0 && imgH > 0) {
                // Escalado inteligente para que no se deformen ni se corran las proporciones
                double escala = Math.max((double) getWidth() / imgW, (double) getHeight() / imgH);
                int anchoFinal = (int) (imgW * escala);
                int altoFinal = (int) (imgH * escala);
                int x = (getWidth() - anchoFinal) / 2;
                int y = (getHeight() - altoFinal) / 2;
                g2.drawImage(img, x, y, anchoFinal, altoFinal, null);
            }
        }
    }

}

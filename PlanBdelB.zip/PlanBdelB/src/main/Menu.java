package main;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

// Importaciones esenciales para la geometría y los degradados del aura
import java.awt.geom.Point2D;
import java.awt.geom.RoundRectangle2D;

public class Menu extends JFrame {

    private GlowPanel panelBase; // Referencia para el aura interactiva de fondo
    // 📌 Atributos para el control del scroll y navegación
    private JScrollPane scrollPane;
    private JPanel panelContenidoScroll;
    
    // Contenedores de las secciones para poder tomarlos como referencia de destino
    private JPanel seccionComoFunciona;
    private JPanel seccionQuienesSomos;
    private JPanel seccionFooter;

  public Menu() {
        // 1. Configuración de la ventana
        setTitle("REMA - Sistema Institucional");
        setSize(1000, 850); 
        setMinimumSize(new Dimension(900, 700)); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); 

        // 2. Panel base con las auras de fondo (GlowPanel)
        panelBase = new GlowPanel();
        panelBase.setLayout(new BorderLayout());
        add(panelBase);

        // ==========================================
        // 🌟 NAV BAR SUPERIOR (Sticky / Fija arriba)
        // ==========================================
        JPanel navbar = new JPanel(new BorderLayout());
        navbar.setOpaque(false); 
        navbar.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40)); 
        navbar.setPreferredSize(new Dimension(1000, 80));

        // Logo oficial
        String rutaImagen = "Imagenes/E.png"; 
        File archivoImagen = new File(rutaImagen);
        Component componenteLogo;

        if (archivoImagen.exists()) {
            ImageIcon iconoOriginal = new ImageIcon(rutaImagen);
            Image imagenEscalada = iconoOriginal.getImage().getScaledInstance(110, 50, Image.SCALE_SMOOTH);
            componenteLogo = new JLabel(new ImageIcon(imagenEscalada));
        } else {
            System.out.println("No se encontró la imagen del logo en: " + archivoImagen.getAbsolutePath());
            componenteLogo = Box.createHorizontalStrut(110); 
        }
        navbar.add(componenteLogo, BorderLayout.WEST);

        // Enlaces interactivos superiores
        JPanel panelEnlaces = new JPanel(new FlowLayout(FlowLayout.RIGHT, 25, 0));
        panelEnlaces.setOpaque(false);

        // Creamos individualmente las etiquetas para poder asignarles eventos de scroll directos
        JLabel lblComoFunciona = new JLabel("¿Cómo funciona?");
        JLabel lblQuienesSomos = new JLabel("Quiénes somos");
        JLabel lblContacto = new JLabel("Contacto");

        JLabel[] enlaces = {lblComoFunciona, lblQuienesSomos, lblContacto};

        for (JLabel lblEnlace : enlaces) {
            lblEnlace.setFont(new Font("Arial", Font.PLAIN, 13));
            lblEnlace.setForeground(new Color(148, 163, 184)); 
            lblEnlace.setCursor(new Cursor(Cursor.HAND_CURSOR));
            
            lblEnlace.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    lblEnlace.setForeground(Color.WHITE);
                }
                @Override
                public void mouseExited(MouseEvent e) {
                    lblEnlace.setForeground(new Color(148, 163, 184));
                }
            });
            panelEnlaces.add(lblEnlace);
        }
        panelEnlaces.setBorder(BorderFactory.createEmptyBorder(12, 0, 0, 0));
        navbar.add(panelEnlaces, BorderLayout.EAST);

        panelBase.add(navbar, BorderLayout.NORTH);

        // ==========================================
        // 📜 CONTENIDO DESLIZABLE (Hero + Features + Quiénes Somos + Testimonios + CTA)
        // ==========================================
        panelContenidoScroll = new JPanel();
        panelContenidoScroll.setLayout(new BoxLayout(panelContenidoScroll, BoxLayout.Y_AXIS));
        panelContenidoScroll.setOpaque(false);

        // --- SECCIÓN 1: HERO (BIENVENIDA) ---
        JPanel seccionHero = new JPanel(new GridBagLayout());
        seccionHero.setOpaque(false);
        seccionHero.setPreferredSize(new Dimension(1000, 520));
        seccionHero.setMinimumSize(new Dimension(1000, 520));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;       
        gbc.fill = GridBagConstraints.HORIZONTAL; 
        gbc.anchor = GridBagConstraints.CENTER;   
        
        // Badge
        JLabel lblBadge = new JLabel("✦  SISTEMA INSTITUCIONAL · 2026", SwingConstants.CENTER);
        lblBadge.setFont(new Font("Arial", Font.BOLD, 10));
        lblBadge.setForeground(new Color(56, 189, 248)); 
        
        JPanel panelBadge = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelBadge.setOpaque(true);
        panelBadge.setBackground(new Color(15, 23, 42)); 
        panelBadge.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(30, 41, 59), 1, true), 
            BorderFactory.createEmptyBorder(6, 16, 6, 16)   
        ));
        panelBadge.add(lblBadge);

        gbc.gridy = 0;       
        gbc.insets = new Insets(20, 20, 25, 20); 
        seccionHero.add(panelBadge, gbc);

        // Título "BIENVENIDOS A"
        JLabel lblTitulo1 = new JLabel("BIENVENIDOS A", SwingConstants.CENTER);
        lblTitulo1.setFont(new Font("Arial", Font.BOLD, 42)); 
        lblTitulo1.setForeground(Color.WHITE); 
        gbc.gridy = 1;       
        gbc.insets = new Insets(0, 20, 5, 20); 
        seccionHero.add(lblTitulo1, gbc);

        // Título "REMA"
        JLabel lblTitulo2 = new JLabel("REMA", SwingConstants.CENTER);
        lblTitulo2.setFont(new Font("Arial", Font.BOLD, 56));
        lblTitulo2.setForeground(new Color(56, 189, 248)); 
        gbc.gridy = 2;       
        gbc.insets = new Insets(0, 20, 20, 20); 
        seccionHero.add(lblTitulo2, gbc);

        // Subtítulo
        JLabel lblSubtitulo = new JLabel("Consulta disponibilidad, solicita herramientas y gestiona devoluciones", SwingConstants.CENTER);
        lblSubtitulo.setFont(new Font("Arial", Font.PLAIN, 14));
        lblSubtitulo.setForeground(new Color(100, 116, 139)); 
        gbc.gridy = 3;       
        gbc.insets = new Insets(0, 20, 35, 20); 
        seccionHero.add(lblSubtitulo, gbc);

        // Botón Iniciar Sesión
        JPanel contenedorBtnLogin = new JPanel(new FlowLayout(FlowLayout.CENTER));
        contenedorBtnLogin.setOpaque(false); 
        
        JButton btnLogin = new JButton("Iniciar Sesión →");
        btnLogin.setFont(new Font("Arial", Font.BOLD, 14));
        
        Color colorBotonNormal = new Color(45, 90, 231); 
        Color colorBotonHover = new Color(79, 115, 246);  
        
        btnLogin.setBackground(colorBotonNormal); 
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setPreferredSize(new Dimension(200, 45)); 
        btnLogin.setFocusPainted(false);
        btnLogin.setCursor(new Cursor(Cursor.HAND_CURSOR)); 
        btnLogin.setBorder(BorderFactory.createEmptyBorder()); 

        btnLogin.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnLogin.setBackground(colorBotonHover); 
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btnLogin.setBackground(colorBotonNormal); 
            }
        });

        contenedorBtnLogin.add(btnLogin);
        gbc.gridy = 4;       
        gbc.insets = new Insets(0, 20, 20, 20);
        seccionHero.add(contenedorBtnLogin, gbc);

        panelContenidoScroll.add(seccionHero);

        // --- SECCIÓN 2: CARACTERÍSTICAS (¿Cómo funciona?) ---
        seccionComoFunciona = new JPanel();
        seccionComoFunciona.setLayout(new BoxLayout(seccionComoFunciona, BoxLayout.Y_AXIS));
        seccionComoFunciona.setOpaque(false);
        seccionComoFunciona.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));

        // Sub-cabecera
        JLabel lblSubQueHacer = new JLabel("¿QUÉ PUEDES HACER?", SwingConstants.CENTER);
        lblSubQueHacer.setFont(new Font("Arial", Font.BOLD, 11));
        lblSubQueHacer.setForeground(new Color(56, 189, 248));
        lblSubQueHacer.setAlignmentX(Component.CENTER_ALIGNMENT);
        seccionComoFunciona.add(lblSubQueHacer);
        seccionComoFunciona.add(Box.createVerticalStrut(10));

        // Título principal
        JLabel lblTituloFeatures = new JLabel("Todo el control del inventario en un solo lugar", SwingConstants.CENTER);
        lblTituloFeatures.setFont(new Font("Arial", Font.BOLD, 28));
        lblTituloFeatures.setForeground(Color.WHITE);
        lblTituloFeatures.setAlignmentX(Component.CENTER_ALIGNMENT);
        seccionComoFunciona.add(lblTituloFeatures);
        seccionComoFunciona.add(Box.createVerticalStrut(12));

        // Subtítulo descriptivo
        JLabel lblDescFeatures = new JLabel("<html><center>Desde consultar disponibilidad hasta aprobar solicitudes — el sistema<br>cubre todo el ciclo de préstamos del instituto.</center></html>", SwingConstants.CENTER);
        lblDescFeatures.setFont(new Font("Arial", Font.PLAIN, 14));
        lblDescFeatures.setForeground(new Color(148, 163, 184));
        lblDescFeatures.setAlignmentX(Component.CENTER_ALIGNMENT);
        seccionComoFunciona.add(lblDescFeatures);
        seccionComoFunciona.add(Box.createVerticalStrut(40));

        // Grid de Tarjetas
        JPanel panelCardsGrid = new JPanel(new GridLayout(1, 4, 15, 0));
        panelCardsGrid.setOpaque(false);
        panelCardsGrid.setMaximumSize(new Dimension(1100, 250));

        panelCardsGrid.add(crearCardFeature("◎", "Catálogo de Equipos", "Consulta disponibilidad en tiempo real de herramientas, laptops y equipos de laboratorio."));
        panelCardsGrid.add(crearCardFeature("◇", "Solicitud de Préstamo", "Solicita equipos en pocos pasos, con validación automática por carrera autorizada."));
        panelCardsGrid.add(crearCardFeature("△", "Control de Devoluciones", "Seguimiento de fechas límite, alertas de atraso y registro de devoluciones al instante."));
        panelCardsGrid.add(crearCardFeature("❑", "Panel Administrativo", "El encargado gestiona inventario, aprueba solicitudes y genera reportes completos."));

        seccionComoFunciona.add(panelCardsGrid);
        panelContenidoScroll.add(seccionComoFunciona);


        // ==========================================
        // 🌟 SECCIÓN 3: QUIÉNES SOMOS (Misión, Visión, Valores)
        // ==========================================
        seccionQuienesSomos = new JPanel();
        seccionQuienesSomos.setLayout(new BoxLayout(seccionQuienesSomos, BoxLayout.Y_AXIS));
        seccionQuienesSomos.setOpaque(false);
        seccionQuienesSomos.setBorder(BorderFactory.createEmptyBorder(60, 40, 60, 40));

        JLabel lblSubQuienes = new JLabel("QUIÉNES SOMOS", SwingConstants.CENTER);
        lblSubQuienes.setFont(new Font("Arial", Font.BOLD, 11));
        lblSubQuienes.setForeground(new Color(56, 189, 248));
        lblSubQuienes.setAlignmentX(Component.CENTER_ALIGNMENT);
        seccionQuienesSomos.add(lblSubQuienes);
        seccionQuienesSomos.add(Box.createVerticalStrut(10));

        JLabel lblTituloQuienes = new JLabel("El equipo detrás de REMA", SwingConstants.CENTER);
        lblTituloQuienes.setFont(new Font("Arial", Font.BOLD, 28));
        lblTituloQuienes.setForeground(Color.WHITE);
        lblTituloQuienes.setAlignmentX(Component.CENTER_ALIGNMENT);
        seccionQuienesSomos.add(lblTituloQuienes);
        seccionQuienesSomos.add(Box.createVerticalStrut(12));

        JLabel lblDescQuienes = new JLabel("<html><center>Manteniendo a Flote el Orden — somos el Instituto Técnico Superior,<br>comprometidos con la educación técnica y el acceso a herramientas de calidad para cada estudiante.</center></html>", SwingConstants.CENTER);
        lblDescQuienes.setFont(new Font("Arial", Font.PLAIN, 14));
        lblDescQuienes.setForeground(new Color(148, 163, 184));
        lblDescQuienes.setAlignmentX(Component.CENTER_ALIGNMENT);
        seccionQuienesSomos.add(lblDescQuienes);
        seccionQuienesSomos.add(Box.createVerticalStrut(40));

        // Grid Misión, Visión, Valores
        JPanel panelMVRGrid = new JPanel(new GridLayout(1, 3, 20, 0));
        panelMVRGrid.setOpaque(false);
        panelMVRGrid.setMaximumSize(new Dimension(1100, 260));

        panelMVRGrid.add(crearCardMisionVision("🎯", "Misión", "Facilitar el acceso a herramientas y equipos de calidad para que cada estudiante pueda desarrollar sus habilidades técnicas sin barreras.", new Color(219, 39, 119)));
        panelMVRGrid.add(crearCardMisionVision("🔭", "Visión", "Ser el sistema de referencia en gestión de inventario institucional en Guatemala, modelo de eficiencia y transparencia.", new Color(59, 130, 246)));
        panelMVRGrid.add(crearCardMisionVision("⚓", "Valores", "Orden, responsabilidad, accesibilidad y tecnología al servicio de la comunidad educativa técnica del instituto.", new Color(16, 185, 129)));

        seccionQuienesSomos.add(panelMVRGrid);
        panelContenidoScroll.add(seccionQuienesSomos);


        // --- SECCIÓN 4: TESTIMONIOS (CON FONDO OSCURO) ---
        JPanel seccionTestimonios = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Fondo ultra oscuro (#02040a)
                g2d.setColor(new Color(2, 4, 10));
                g2d.fillRect(0, 0, getWidth(), getHeight());
                
                // Línea divisoria superior sutil
                g2d.setColor(new Color(15, 23, 42));
                g2d.drawLine(0, 0, getWidth(), 0);
                
                g2d.dispose();
            }
        };
        seccionTestimonios.setLayout(new BoxLayout(seccionTestimonios, BoxLayout.Y_AXIS));
        seccionTestimonios.setOpaque(false); 
        seccionTestimonios.setBorder(BorderFactory.createEmptyBorder(60, 40, 60, 40));

        // Sub-cabecera
        JLabel lblSubTest = new JLabel("TESTIMONIOS", SwingConstants.CENTER);
        lblSubTest.setFont(new Font("Arial", Font.BOLD, 11));
        lblSubTest.setForeground(new Color(56, 189, 248));
        lblSubTest.setAlignmentX(Component.CENTER_ALIGNMENT);
        seccionTestimonios.add(lblSubTest);
        seccionTestimonios.add(Box.createVerticalStrut(10));

        // Título principal
        JLabel lblTituloTest = new JLabel("Lo que dicen estudiantes y encargados", SwingConstants.CENTER);
        lblTituloTest.setFont(new Font("Arial", Font.BOLD, 28));
        lblTituloTest.setForeground(Color.WHITE);
        lblTituloTest.setAlignmentX(Component.CENTER_ALIGNMENT);
        seccionTestimonios.add(lblTituloTest);
        seccionTestimonios.add(Box.createVerticalStrut(40));

        // Grid de Testimonios
        JPanel panelTestGrid = new JPanel(new GridLayout(1, 3, 20, 0));
        panelTestGrid.setOpaque(false);
        panelTestGrid.setMaximumSize(new Dimension(1100, 220));

        panelTestGrid.add(crearCardTestimonio("★★★★★", "El sistema me avisa cuando se acerca la fecha de devolución. ¡Nunca más me han cobrado atraso!", "Pedro R.", "Estudiante - Mecánica"));
        panelTestGrid.add(crearCardTestimonio("★★★★★", "El panel de control me permite aprobar solicitudes y llevar el inventario sin papeles ni hojas de Excel.", "Mariela T.", "Encargada del Taller"));
        panelTestGrid.add(crearCardTestimonio("★★★★☆", "Antes tenía que ir físicamente al taller para saber si había equipo disponible. ¡Ahora lo veo desde mi celular!", "Carlos G.", "Estudiante - Computación"));

        seccionTestimonios.add(panelTestGrid);
        panelContenidoScroll.add(seccionTestimonios);


        // ==========================================
        // 🌟 SECCIÓN 5: BANNER DE LLAMADO A LA ACCIÓN (CTA)
        // ==========================================
        JPanel seccionCTA = new JPanel();
        seccionCTA.setLayout(new BoxLayout(seccionCTA, BoxLayout.Y_AXIS));
        seccionCTA.setOpaque(false);
        seccionCTA.setBorder(BorderFactory.createEmptyBorder(20, 40, 80, 40));
        seccionCTA.add(crearBannerCTA());
        
        panelContenidoScroll.add(seccionCTA);

        // --- SECCIÓN 6: FOOTER (Contacto) ---
        seccionFooter = crearFooter();
        panelContenidoScroll.add(seccionFooter);

        // ==========================================
        // ⚙️ CONFIGURACIÓN DEL JSCROLLPANE
        // ==========================================
        scrollPane = new JScrollPane(panelContenidoScroll);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16); 
        scrollPane.getVerticalScrollBar().setPreferredSize(new Dimension(8, 0)); 
        scrollPane.getVerticalScrollBar().setBackground(new Color(3, 7, 18));
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setOpaque(false);

        panelBase.add(scrollPane, BorderLayout.CENTER);

        // Vinculamos el movimiento del ratón general
        vincularEventosMouse(this);

        // =================================================================
        // ⚓ EVENTOS DE NAVEGACIÓN (SCROLL AL HACER CLIC)
        // =================================================================
        lblComoFunciona.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent evt) {
                if (scrollPane != null && panelContenidoScroll != null && seccionComoFunciona != null) {
                    Point punto = SwingUtilities.convertPoint(seccionComoFunciona, 0, 0, panelContenidoScroll);
                    scrollPane.getViewport().setViewPosition(new Point(0, Math.max(0, punto.y - 20)));
                }
            }
        });

        lblQuienesSomos.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent evt) {
                if (scrollPane != null && panelContenidoScroll != null && seccionQuienesSomos != null) {
                    Point punto = SwingUtilities.convertPoint(seccionQuienesSomos, 0, 0, panelContenidoScroll);
                    scrollPane.getViewport().setViewPosition(new Point(0, Math.max(0, punto.y - 20)));
                }
            }
        });

        lblContacto.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent evt) {
                if (scrollPane != null && panelContenidoScroll != null && seccionFooter != null) {
                    Point punto = SwingUtilities.convertPoint(seccionFooter, 0, 0, panelContenidoScroll);
                    scrollPane.getViewport().setViewPosition(new Point(0, Math.max(0, punto.y - 20)));
                }
            }
        });
    }

   // Método actualizado para permitir selección interactiva con resaltado completo (Glow Border)
    private JPanel crearCardMisionVision(String icono, String titulo, String descripcion, Color colorAcento) {
        // Objeto anónimo para poder guardar el estado de selección y repintar dinámicamente
        class TarjetaMVR extends JPanel {
            private boolean seleccionada = false;

            public void setSeleccionada(boolean sel) {
                this.seleccionada = sel;
                repaint();
            }

            public boolean isSeleccionada() {
                return seleccionada;
            }

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                int w = getWidth();
                int h = getHeight();

                // 1. Fondo oscuro interno tradicional de la tarjeta
                g2d.setColor(new Color(11, 17, 32)); 
                g2d.fill(new RoundRectangle2D.Float(0, 0, w, h, 16, 16));
                
                // 2. Si está seleccionada, pintamos un resplandor de fondo y borde iluminado completo
                if (seleccionada) {
                    // Sutil resplandor interno del color de acento
                    g2d.setColor(new Color(colorAcento.getRed(), colorAcento.getGreen(), colorAcento.getBlue(), 12));
                    g2d.fill(new RoundRectangle2D.Float(0, 0, w, h, 16, 16));

                    // Borde iluminado completo (Contorno neón)
                    g2d.setColor(colorAcento);
                    g2d.setStroke(new BasicStroke(1.5f));
                    g2d.draw(new RoundRectangle2D.Float(0, 0, w - 1, h - 1, 16, 16));
                } else {
                    // Borde estándar apagado si no está seleccionada
                    g2d.setColor(new Color(30, 41, 59));
                    g2d.setStroke(new BasicStroke(1f));
                    g2d.draw(new RoundRectangle2D.Float(0, 0, w - 1, h - 1, 16, 16));
                }
                
                // 3. Línea superior brillante estética (siempre visible o más intensa al seleccionar)
                g2d.setColor(colorAcento);
                g2d.setStroke(new BasicStroke(seleccionada ? 2.5f : 2f));
                g2d.draw(new RoundRectangle2D.Float(20, 0, w - 40, 1, 0, 0));
                
                g2d.dispose();
            }
        }

        TarjetaMVR card = new TarjetaMVR();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setOpaque(false);
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));
        card.setBorder(BorderFactory.createEmptyBorder(25, 20, 25, 20));

        // Icono cuadrado con fondo suave personalizado
        JPanel panelIcono = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(new Color(colorAcento.getRed(), colorAcento.getGreen(), colorAcento.getBlue(), 25));
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2d.dispose();
            }
        };
        panelIcono.setLayout(new GridBagLayout());
        panelIcono.setOpaque(false);
        panelIcono.setPreferredSize(new Dimension(38, 38));
        panelIcono.setMaximumSize(new Dimension(38, 38));
        panelIcono.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblIcono = new JLabel(icono);
        lblIcono.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 16));
        panelIcono.add(lblIcono);
        card.add(panelIcono);
        card.add(Box.createVerticalStrut(20));

        // Título
        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 16));
        lblTitulo.setForeground(colorAcento); 
        lblTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(lblTitulo);
        card.add(Box.createVerticalStrut(10));

        // Descripción de la tarjeta
        JLabel lblDesc = new JLabel("<html><body style='width: 190px;'>" + descripcion + "</body></html>");
        lblDesc.setFont(new Font("Arial", Font.PLAIN, 12));
        lblDesc.setForeground(new Color(148, 163, 184));
        lblDesc.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(lblDesc);

        // Listener de Clic para manejar la exclusividad (apagar las otras al encender esta)
        MouseAdapter clickListener = new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                Container contenedorPadre = card.getParent();
                if (contenedorPadre != null) {
                    // Recorre las tarjetas hermanas en el grid para apagarlas
                    for (Component comp : contenedorPadre.getComponents()) {
                        if (comp instanceof TarjetaMVR) {
                            ((TarjetaMVR) comp).setSeleccionada(false);
                        }
                    }
                }
                // Activa la tarjeta clickeada
                card.setSeleccionada(true);
            }
        };

        // Asignamos el listener tanto al panel como a sus componentes internos para que no se pierda el clic
        card.addMouseListener(clickListener);
        for (Component c : card.getComponents()) {
            c.addMouseListener(clickListener);
        }

        return card;
    }

    // Método para crear el gran Banner de llamado a la acción (CTA) de abajo
    private JPanel crearBannerCTA() {
        
        JPanel banner = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                int w = getWidth();
                int h = getHeight();
                
                // Fondo base oscuro
                g2d.setColor(new Color(11, 17, 32));
                g2d.fill(new RoundRectangle2D.Float(0, 0, w, h, 20, 20));
                
                // Degradado interior azul resplandeciente (Glow lineal/radial combinado)
                LinearGradientPaint lgp = new LinearGradientPaint(
                    0, 0, w, h,
                    new float[]{0.0f, 0.5f, 1.0f},
                    new Color[]{
                        new Color(30, 58, 138, 60), // Azul oscuro translúcido
                        new Color(45, 90, 231, 20),
                        new Color(11, 17, 32, 0)
                    }
                );
                g2d.setPaint(lgp);
                g2d.fill(new RoundRectangle2D.Float(0, 0, w, h, 20, 20));
                
                // Borde con brillo sutil
                g2d.setColor(new Color(56, 189, 248, 40));
                g2d.setStroke(new BasicStroke(1f));
                g2d.draw(new RoundRectangle2D.Float(0, 0, w - 1, h - 1, 20, 20));
                
                g2d.dispose();
            }
        };
        banner.setLayout(new BorderLayout());
        banner.setMaximumSize(new Dimension(1100, 150));
        banner.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        // Textos izquierdos
        JPanel panelTextos = new JPanel();
        panelTextos.setLayout(new BoxLayout(panelTextos, BoxLayout.Y_AXIS));
        panelTextos.setOpaque(false);

        JLabel lblTit = new JLabel("Accede al sistema ahora.");
        lblTit.setFont(new Font("Arial", Font.BOLD, 26));
        lblTit.setForeground(Color.WHITE);
        panelTextos.add(lblTit);
        panelTextos.add(Box.createVerticalStrut(8));

        JLabel lblSub = new JLabel("Consulta equipos, solicita préstamos y gestiona devoluciones desde cualquier dispositivo.");
        lblSub.setFont(new Font("Arial", Font.PLAIN, 13));
        lblSub.setForeground(new Color(148, 163, 184));
        panelTextos.add(lblSub);

        banner.add(panelTextos, BorderLayout.WEST);

        // Botón derecho
        JPanel panelBoton = new JPanel(new GridBagLayout());
        panelBoton.setOpaque(false);

        JButton btnCTA = new JButton("Iniciar Sesión →");
        btnCTA.setFont(new Font("Arial", Font.BOLD, 13));
        btnCTA.setBackground(new Color(59, 130, 246));
        btnCTA.setForeground(Color.WHITE);
        btnCTA.setPreferredSize(new Dimension(160, 40));
        btnCTA.setFocusPainted(false);
        btnCTA.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnCTA.setBorder(BorderFactory.createEmptyBorder());

        btnCTA.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) { btnCTA.setBackground(new Color(96, 165, 250)); }
            @Override
            public void mouseExited(MouseEvent e) { btnCTA.setBackground(new Color(59, 130, 246)); }
        });

        panelBoton.add(btnCTA);
        banner.add(panelBoton, BorderLayout.EAST);

        return banner;
    }
    

    // Método dinámico para construir las tarjetas DE CARACTERÍSTICAS
    private JPanel crearCardFeature(String icono, String titulo, String descripcion) {
        class HoverCardPanel extends JPanel {
            private Point mouseInsidePoint = new Point(-1000, -1000);

            public void setMousePoint(Point p) {
                this.mouseInsidePoint = p;
                repaint();
            }

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                if (mouseInsidePoint.x > -500) {
                    float radius = getWidth() * 0.75f; 
                    float[] dist = {0.0f, 1.0f};
                    Color[] colors = {
                        new Color(56, 189, 248, 35), 
                        new Color(56, 189, 248, 0)   
                    };
                    RadialGradientPaint paintAura = new RadialGradientPaint(mouseInsidePoint, radius, dist, colors);
                    g2d.setPaint(paintAura);
                    g2d.fill(new RoundRectangle2D.Float(-30, -30, getWidth() + 60, getHeight() + 60, 20, 20)); 
                }

                g2d.setColor(new Color(11, 17, 32)); 
                g2d.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 16, 16));
                
                g2d.setColor(new Color(30, 41, 59));
                g2d.setStroke(new BasicStroke(1f));
                g2d.draw(new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 16, 16));
                
                g2d.dispose();
            }
        }

        HoverCardPanel card = new HoverCardPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(25, 20, 25, 20));

        MouseAdapter mouseHoverListener = new MouseAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) { card.setMousePoint(e.getPoint()); }
            @Override
            public void mouseDragged(MouseEvent e) { card.setMousePoint(e.getPoint()); }
            @Override
            public void mouseExited(MouseEvent e) { card.setMousePoint(new Point(-1000, -1000)); }
        };
        card.addMouseMotionListener(mouseHoverListener);
        card.addMouseListener(mouseHoverListener);

        JPanel panelIcono = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(new Color(56, 189, 248, 20));
                g2d.fillOval(0, 0, getWidth(), getHeight());
                g2d.setColor(new Color(56, 189, 248, 50));
                g2d.drawOval(0, 0, getWidth() - 1, getHeight() - 1);
                g2d.dispose();
            }
        };
        panelIcono.setLayout(new GridBagLayout());
        panelIcono.setOpaque(false);
        panelIcono.setPreferredSize(new Dimension(40, 40));
        panelIcono.setMaximumSize(new Dimension(40, 40));

        JLabel lblIcono = new JLabel(icono);
        lblIcono.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 18));
        lblIcono.setForeground(new Color(56, 189, 248));
        panelIcono.add(lblIcono);

        card.add(panelIcono);
        card.add(Box.createVerticalStrut(20));

        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 15));
        lblTitulo.setForeground(Color.WHITE);
        card.add(lblTitulo);
        card.add(Box.createVerticalStrut(10));

        JLabel lblDesc = new JLabel("<html><body style='width: 140px;'>" + descripcion + "</body></html>");
        lblDesc.setFont(new Font("Arial", Font.PLAIN, 12));
        lblDesc.setForeground(new Color(148, 163, 184));
        card.add(lblDesc);

        for (Component c : card.getComponents()) {
            c.addMouseMotionListener(new MouseAdapter() {
                @Override
                public void mouseMoved(MouseEvent e) {
                    Point p = SwingUtilities.convertPoint(e.getComponent(), e.getPoint(), card);
                    card.setMousePoint(p);
                }
            });
        }

        return card;
    }

    // Método dinámico para construir las tarjetas DE TESTIMONIOS
    private JPanel crearCardTestimonio(String estrellas, String texto, String nombre, String rol) {
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                g2d.setColor(new Color(11, 17, 32)); 
                g2d.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 16, 16));
                
                g2d.setColor(new Color(30, 41, 59));
                g2d.setStroke(new BasicStroke(1f));
                g2d.draw(new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 16, 16));
                
                g2d.dispose();
            }
        };
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel lblEstrellas = new JLabel(estrellas);
        lblEstrellas.setFont(new Font("Arial", Font.BOLD, 12));
        lblEstrellas.setForeground(new Color(56, 189, 248)); 
        card.add(lblEstrellas);
        card.add(Box.createVerticalStrut(15));

        JLabel lblTexto = new JLabel("<html><body style='width: 200px; font-style: italic;'>" + texto + "</body></html>");
        lblTexto.setFont(new Font("Arial", Font.PLAIN, 13));
        lblTexto.setForeground(Color.WHITE);
        lblTexto.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(lblTexto);
        card.add(Box.createVerticalStrut(20));

        JPanel panelInfoUser = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        panelInfoUser.setOpaque(false);
        panelInfoUser.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel avatar = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(new Color(56, 189, 248, 30));
                g2d.fillOval(0, 0, getWidth(), getHeight());
                g2d.dispose();
            }
        };
        avatar.setPreferredSize(new Dimension(32, 32));
        avatar.setOpaque(false);
        JLabel lblInicial = new JLabel(String.valueOf(nombre.charAt(0)));
        lblInicial.setFont(new Font("Arial", Font.BOLD, 14));
        lblInicial.setForeground(new Color(56, 189, 248));
        avatar.add(lblInicial);
        panelInfoUser.add(avatar);

        JPanel panelTextUser = new JPanel(new GridLayout(2, 1));
        panelTextUser.setOpaque(false);
        
        JLabel lblNombre = new JLabel(nombre);
        lblNombre.setFont(new Font("Arial", Font.BOLD, 13));
        lblNombre.setForeground(Color.WHITE);
        panelTextUser.add(lblNombre);

        JLabel lblRol = new JLabel(rol);
        lblRol.setFont(new Font("Arial", Font.PLAIN, 11));
        lblRol.setForeground(new Color(148, 163, 184));
        panelTextUser.add(lblRol);

        panelInfoUser.add(panelTextUser);
        card.add(panelInfoUser);

        return card;
    }

    private void vincularEventosMouse(Component componente) {
        componente.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                Point p = SwingUtilities.convertPoint(e.getComponent(), e.getPoint(), panelBase);
                panelBase.actualizarMouse(p);
            }
        });
        componente.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent e) {
                panelBase.actualizarMouse(new Point(-1000, -1000));
            }
        });

        if (componente instanceof Container) {
            for (Component hijo : ((Container) componente).getComponents()) {
                vincularEventosMouse(hijo);
            }
        }
    }

    private static class GlowPanel extends JPanel {
        private Point mousePoint = new Point(-1000, -1000);

        public GlowPanel() {
            setBackground(new Color(3, 7, 18)); 
        }

        public void actualizarMouse(Point p) {
            this.mousePoint = p;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();

            Point centroGlow1 = new Point((int)(w * 0.15), (int)(h * 0.15));
            float radioGlow1 = 350f;
            RadialGradientPaint glowEstatico1 = new RadialGradientPaint(
                centroGlow1,
                radioGlow1,
                new float[]{0.0f, 1.0f},
                new Color[]{
                    new Color(56, 189, 248, 15), 
                    new Color(56, 189, 248, 0)   
                }
            );
            g2d.setPaint(glowEstatico1);
            g2d.fillRect(0, 0, w, h);

            Point centroGlow2 = new Point((int)(w * 0.85), (int)(h * 0.8));
            float radioGlow2 = 450f;
            RadialGradientPaint glowEstatico2 = new RadialGradientPaint(
                centroGlow2,
                radioGlow2,
                new float[]{0.0f, 1.0f},
                new Color[]{
                    new Color(45, 90, 231, 12),  
                    new Color(45, 90, 231, 0)   
                }
            );
            g2d.setPaint(glowEstatico2);
            g2d.fillRect(0, 0, w, h);

            if (mousePoint.x > -500) {
                float radioLuz = 280f; 
                float[] distribucionGlow = {0.0f, 1.0f}; 
                Color[] coloresGlow = {
                    new Color(56, 189, 248, 25), 
                    new Color(56, 189, 248, 0)   
                };

                RadialGradientPaint degradadoRadial = new RadialGradientPaint(
                    mousePoint,
                    radioLuz,
                    distribucionGlow,
                    coloresGlow
                );

                g2d.setPaint(degradadoRadial);
                g2d.fillRect(0, 0, w, h);
            }
            g2d.dispose();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Menu().setVisible(true);
        });
    }
    
// 🌟 MÉTODO ACTUALIZADO: FOOTER (PIE DE PÁGINA INTERACTIVO CON IMAGEN)
    private JPanel crearFooter() {
        JPanel footerMain = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setColor(new Color(2, 4, 10)); 
                g2d.fillRect(0, 0, getWidth(), getHeight());
                g2d.dispose();
            }
        };
        footerMain.setLayout(new BoxLayout(footerMain, BoxLayout.Y_AXIS));
        footerMain.setOpaque(false);
        footerMain.setBorder(BorderFactory.createEmptyBorder(50, 60, 30, 60));

        JPanel gridColumnas = new JPanel(new GridLayout(1, 4, 40, 0));
        gridColumnas.setOpaque(false);

        // --- Columna 1: Info Institucional con imagen E.png ---
        JPanel col1 = new JPanel();
        col1.setLayout(new BoxLayout(col1, BoxLayout.Y_AXIS));
        col1.setOpaque(false);
        
        JLabel lblLogoF = new JLabel();
        try {
            // Ruta exacta en tu equipo hacia la carpeta 'imagenes'
            String rutaImagen = "C:\\Users\\Computacion\\Documents\\NetBeansProjects\\PlanBdelB\\imagenes\\E.png";
            java.io.File archivoImg = new java.io.File(rutaImagen);
            
            if (archivoImg.exists()) {
                ImageIcon iconoOriginal = new ImageIcon(rutaImagen);
                // Ajusta aquí el tamaño de la imagen (Ej: 45 de ancho y 45 de alto)
                Image imgEscalada = iconoOriginal.getImage().getScaledInstance(45, 45, Image.SCALE_SMOOTH);
                lblLogoF.setIcon(new ImageIcon(imgEscalada));
            } else {
                // Texto de respaldo si el archivo no existiera en el disco
                lblLogoF.setText("🔱 REMA");
                lblLogoF.setFont(new Font("Arial", Font.BOLD, 16));
                lblLogoF.setForeground(Color.WHITE);
            }
        } catch (Exception e) {
            lblLogoF.setText("🔱 REMA");
            lblLogoF.setFont(new Font("Arial", Font.BOLD, 16));
            lblLogoF.setForeground(Color.WHITE);
        }
        col1.add(lblLogoF);
        col1.add(Box.createVerticalStrut(15));
        
        JLabel lblDescF = new JLabel("<html><body style='width: 180px;'>Sistema institucional para préstamo de herramientas, equipos de laboratorio y dispositivos de los talleres.</body></html>");
        lblDescF.setFont(new Font("Arial", Font.PLAIN, 12));
        lblDescF.setForeground(new Color(100, 116, 139));
        col1.add(lblDescF);
        col1.add(Box.createVerticalStrut(20));
        
        JPanel filaSociales = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        filaSociales.setOpaque(false);
        String[] redes = {"TW", "IG", "YT", "LI"};
        for (String red : redes) {
            JLabel badge = new JLabel(red, SwingConstants.CENTER);
            badge.setFont(new Font("Arial", Font.BOLD, 10));
            badge.setForeground(new Color(56, 189, 248)); 
            badge.setPreferredSize(new Dimension(32, 26));
            badge.setBorder(new javax.swing.border.LineBorder(new Color(30, 41, 59), 1, true));
            filaSociales.add(badge);
        }
        col1.add(filaSociales);
        gridColumnas.add(col1);

        // --- Columna 2: Sistema ---
        gridColumnas.add(crearColumnaEnlaces("SISTEMA", new String[]{"Catálogo de Equipos", "Solicitar Préstamo", "Mis Préstamos", "Panel Admin"}));
        
        // --- Columna 3: Áreas ---
        gridColumnas.add(crearColumnaEnlaces("ÁREAS", new String[]{"Computación", "Mecánica", "Electricidad", "Laboratorios"}));
        
        // --- Columna 4: Contacto ---
        gridColumnas.add(crearColumnaEnlaces("CONTACTO", new String[]{"talleres@instituto.edu.gt", "+5202 2345 6789", "Ciudad de Guatemala", "Lun-Vie 7-17h"}));

        footerMain.add(gridColumnas);
        footerMain.add(Box.createVerticalStrut(40));

        // --- Barra inferior ---
        JPanel barraInferior = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(new Color(30, 41, 59, 120)); 
                g.drawLine(0, 0, getWidth(), 0);
            }
        };
        barraInferior.setOpaque(false);
        barraInferior.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));

        JLabel lblCopyright = new JLabel("© 2026 Instituto Técnico Superior - Sistema de Gestión de Préstamos");
        lblCopyright.setFont(new Font("Arial", Font.PLAIN, 11));
        lblCopyright.setForeground(new Color(100, 116, 139));
        barraInferior.add(lblCopyright, BorderLayout.WEST);

        JPanel panelLegales = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
        panelLegales.setOpaque(false);
        String[] legales = {"Privacidad", "Términos", "Cookies"};
        for (String leg : legales) {
            JLabel lblLeg = new JLabel(leg);
            lblLeg.setFont(new Font("Arial", Font.PLAIN, 11));
            lblLeg.setForeground(new Color(100, 116, 139));
            panelLegales.add(lblLeg);
        }
        barraInferior.add(panelLegales, BorderLayout.EAST);
        footerMain.add(barraInferior);

        return footerMain;
    }

    // Método de soporte para generar cada columna de textos rápidamente
    private JPanel crearColumnaEnlaces(String titulo, String[] enlaces) {
        JPanel col = new JPanel();
        col.setLayout(new BoxLayout(col, BoxLayout.Y_AXIS));
        col.setOpaque(false);

        JLabel lblTit = new JLabel(titulo);
        lblTit.setFont(new Font("Arial", Font.BOLD, 11));
        lblTit.setForeground(new Color(56, 189, 248)); // Título de columna celeste
        col.add(lblTit);
        col.add(Box.createVerticalStrut(15));

        for (String link : enlaces) {
            JLabel lblLink = new JLabel(link);
            lblLink.setFont(new Font("Arial", Font.PLAIN, 13));
            lblLink.setForeground(new Color(148, 163, 184)); // Gris Slate elegante
            col.add(lblLink);
            col.add(Box.createVerticalStrut(10));
        }
        return col;
    }
    
    private void hacerScrollA(JPanel seccionDestino) {
        if (scrollPane != null && panelContenidoScroll != null && seccionDestino != null) {
            // SwingUtilities calcula la posición 'Y' exacta de la sección respecto al contenedor principal
            java.awt.Point puntoDestino = SwingUtilities.convertPoint(seccionDestino, 0, 0, panelContenidoScroll);
            
            // Ajustamos el scroll restándole un pequeño margen (ej. 20px) para que no quede tan pegado arriba
            scrollPane.getViewport().setViewPosition(new java.awt.Point(0, Math.max(0, puntoDestino.y - 20)));
        }
    }
    
}